"""Plot and audit the frozen paired matrix without rerunning simulations."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from paired_matrix import SPEEDS, MANEUVERS, configurations, case_id

ROOT = Path(__file__).resolve().parent
DATA = ROOT/"paired_results"


def main():
    summary = json.loads((ROOT/"paired_summary.json").read_text())
    cases = summary["cases"]
    by_id = {case["id"]:case for case in cases}
    names = list(configurations())
    groups = [(speed, maneuver) for speed in SPEEDS for maneuver in MANEUVERS]
    common = []
    for speed, maneuver in groups:
        loads = {name:np.load(DATA/f"{case_id(speed,maneuver,name)}.npz") for name in names}
        length = min(len(item["time"]) for item in loads.values())
        for name, item in loads.items():
            ref = loads["matched"]["reference"][:length]
            assert np.array_equal(ref, item["reference"][:length])
            err = item["error"][:length]
            diagnostic = item["diagnostic"][:length]
            rmse = np.sqrt(np.mean(err**2, axis=0))
            diagnostic_rmse = np.sqrt(np.mean(diagnostic**2, axis=0))
            common.append({"id":case_id(speed,maneuver,name), "time_end_s":float(item["time"][length-1]),
                           "RMSE":rmse.tolist(), "mean_error":err.mean(axis=0).tolist(),
                           "diagnostic_RMSE":diagnostic_rmse.tolist(),
                           "position_RMSE_norm_m":float(np.sqrt(np.sum(rmse[:3]**2)))})
    (ROOT/"paired_allfactor_common_window.json").write_text(json.dumps({
        "purpose":"all 16 factors use same shortest time prefix within each speed/maneuver, avoiding unequal-window ranking", "cases":common},indent=2)+"\n")
    common_by_id = {item["id"]:item for item in common}

    fig, axes = plt.subplots(2,1,figsize=(15,10),layout="constrained")
    energy = np.empty((len(groups),len(names)))
    failure = np.empty_like(energy)
    for i,(speed,maneuver) in enumerate(groups):
        baseline = common_by_id[case_id(speed,maneuver,"matched")]["position_RMSE_norm_m"]
        for j,name in enumerate(names):
            identifier = case_id(speed,maneuver,name)
            energy[i,j] = np.log10(common_by_id[identifier]["position_RMSE_norm_m"]/baseline)
            failure[i,j] = by_id[identifier]["duration_observed_s"]
    p = axes[0].imshow(energy,aspect="auto",cmap="coolwarm",vmin=-1,vmax=1)
    axes[0].set_title("Position RMS ratio vs matched: log10, all-factor common prefix within each row")
    fig.colorbar(p,ax=axes[0],label="log10(RMS / matched RMS)",pad=.01,extend="both")
    p = axes[1].imshow(failure,aspect="auto",cmap="viridis",vmin=0,vmax=24)
    axes[1].set_title("First diagnostic boundary time (seconds); 24 = completed, not a stability guarantee")
    fig.colorbar(p,ax=axes[1],label="seconds",pad=.01)
    for i,(speed,maneuver) in enumerate(groups):
        for j,name in enumerate(names):
            if failure[i,j] < 24:
                axes[1].text(j,i,f"{failure[i,j]:.1f}",ha="center",va="center",fontsize=8,color="white" if failure[i,j]<12 else "black")
    for ax in axes:
        ax.set_xticks(range(len(names)),names,rotation=50,ha="right")
        ax.set_yticks(range(len(groups)),[f"{speed:g} m/s {maneuver}" for speed,maneuver in groups])
    fig.savefig(ROOT/"paired_matrix.png",dpi=170)
    fig.savefig(ROOT/"paired_matrix.pdf")
    plt.close(fig)

    fig,axes=plt.subplots(3,2,figsize=(12,10),layout="constrained",sharex="col")
    selection=[(12.,"coupled"),(18.,"straight")]
    lines=["matched","fin_0.9","tau_2","second_fins","fin_0.9_second_all"]
    for col,(speed,maneuver) in enumerate(selection):
        for name in lines if col==0 else ["matched","mass_0.9","damping_1.1","thrust_0.9","second_all"]:
            data=np.load(DATA/f"{case_id(speed,maneuver,name)}.npz")
            t=data["time"]
            axes[0,col].plot(t,data["diagnostic"][:,1] if col==0 else data["error"][:,0],label=name)
            axes[1,col].plot(t,data["diagnostic"][:,2],label=name)
            axes[2,col].plot(t,data["actual"][:,0]/1.5e6,label=name)
        axes[0,col].set_title(f"{speed:g} m/s, {maneuver}")
        axes[0,col].set_ylabel("Depth error [m]" if col==0 else "North reference - output [m]")
        axes[1,col].set_ylabel("Tangent-speed error [m/s]")
        axes[1,col].axhline(2,color="k",lw=.7,ls="--")
        axes[1,col].axhline(-2,color="k",lw=.7,ls="--")
        axes[2,col].set_ylabel("Actual thrust / 1.5 MN")
        axes[2,col].axhline(1,color="k",lw=.7,ls="--")
        axes[2,col].set_xlabel("Time [s]")
        axes[0,col].legend(fontsize=8)
        for ax in axes[:,col]:
            ax.grid(alpha=.25)
    fig.savefig(ROOT/"paired_mechanisms.png",dpi=170)
    fig.savefig(ROOT/"paired_mechanisms.pdf")
    plt.close(fig)

    failures=[case for case in cases if case["first_diagnostic_limit_violation"]]
    lines=["# 配对闭环实验补充结果", "",
        f"共完成 {len(cases)} 条确定性闭环记录，{len(failures)} 条触发预先定义的诊断边界。该计数不是失效概率；24 s 未越界也不是稳定性证明。", "",
        "## 冻结协议与实现验证", "",
        "3 个初始北向航速（12、15、18 m/s）×4 类机动（速度变化直线、水平转弯及反向、纯深度、耦合）×16 个植物配置。固定原始 CondensedActuatorMPC、N=35、0.1 s 控制周期、RK4 5×0.02 s。所有失配相对于 MISMATCHED_PLANT；单因素为质量、阻尼、推力增益、两舵增益各±10%，全通道延迟1/5子步（基线3），全通道时间常数0.5/2倍；另测二阶全通道、二阶仅双舵、双舵0.9+二阶全通道。质量因子同时作用于惯性矩阵和科氏项，阻尼因子作用于整个 D_COEFF（含俯仰负阻尼项），不能简单解释为单一阻力增减。", "",
        "每组完全相同的初始艇体状态、基线直航配平推力、执行器、历史队列和MPC初始计划；质量/阻尼/推力失配没有单独重新配平。因此这些记录包含共同初始配平下的参数阶跃效应。参考位置的解析导数严格等于参考速度，姿态由切向量给出；north速度固定不等于曲线全程切向速度固定。无噪声、洋流、RL、FSP或残差补偿。", "",
        "植物用独立CasADi RK4实现；对Torch原实现使用随机指令、异质delay/tau/增益，在3种执行器结构共90步交叉验证，最大绝对差1.11e-16。12条matched的完整一步预测误差均要求≤1e-9。协议和源代码哈希冻结于 paired_protocol.json。", "",
        "每0.02 s检查横向误差8 m、深度误差5 m、切向速度误差2 m/s、绝对俯仰40°，首次超过即停止并保留该采样。每0.1 s记录命令饱和、每0.02 s记录实际执行器饱和，二者分别统计。边界是研究诊断线，不是已认证安全包线。", "",
        "RMSE、偏差、最大误差及中心化方差比VR均在失配/匹配相同时间前缀计算，零方差分母返回null。paired_summary记录逐对前缀；paired_allfactor_common_window将同一工况全部16例再次裁成共同最短前缀，供跨因素比较。主图上半部采用后一口径，避免把较早终止病例与24 s完整病例直接比较。", "",
        "## 各工况首越界", "", "|航速|机动|越界配置数/16|最早配置|时间 s|首越界项|", "|---:|---|---:|---|---:|---|"]
    for speed,maneuver in groups:
        subset=[c for c in failures if c["speed_mps"]==speed and c["maneuver"]==maneuver]
        earliest=min(subset,key=lambda c:c["duration_observed_s"]) if subset else None
        time_label = f"{earliest['duration_observed_s']:.2f}" if earliest else "—"
        lines.append(f"|{speed:g}|{maneuver}|{len(subset)}|{earliest['name'] if earliest else '—'}|{time_label}|{','.join(earliest['first_diagnostic_limit_violation']['kinds']) if earliest else '—'}|")
    lines += ["", "## 匹配基线也存在跟踪误差", "", "|航速|机动|完成时间 s|位置向量RMSE m|深度RMSE m|切向速度RMSE m/s|推力命令饱和占比|QP失败|", "|---:|---|---:|---:|---:|---:|---:|---:|"]
    for c in cases:
        if c["name"]=="matched":
            lines.append(f"|{c['speed_mps']:g}|{c['maneuver']}|{c['duration_observed_s']:.2f}|{np.linalg.norm(c['RMSE'][:3]):.4f}|{c['diagnostic_RMSE'][1]:.4f}|{c['diagnostic_RMSE'][2]:.4f}|{c['command_saturation_fraction'][0]:.1%}|{c['qp_failures']}|")
    lines += ["", "## 因素总览", "", "|因素|越界数/12|最早边界 s|", "|---|---:|---:|"]
    for name in names:
        subset=[c for c in failures if c["name"]==name]
        time_label = f"{min(c['duration_observed_s'] for c in subset):.2f}" if subset else "—"
        lines.append(f"|{name}|{len(subset)}|{time_label}|")
    lines += ["", "## 主要判断与可解释边界", "",
        "最危险的组合是两舵增益降低10%叠加二阶执行器：12个速度/机动组合中6个在2.80–5.38 s首次越界。12 m/s水平机动先越切向速度误差界（2.80 s）；15 m/s纯深度和耦合先越40°俯仰界（5.36/5.10 s）。因此危险不能只用单一深度RMSE描述：横向、垂向和推进状态会通过非线性运动学/科氏项共同影响切向速度。", "",
        "单因素中，全通道时间常数加倍和二阶全通道各在3个工况越界；仅双舵二阶在2个工况越界。12 m/s耦合的二阶全通道/仅双舵越界时间6.22/6.24 s非常接近，支持该工况主要关注舵动态。15 m/s纯深度却只有全通道二阶在5.58 s越界，仅双舵二阶完成24 s；不能把所有结构失配都归为舵问题，推力执行器动态在部分工况有关键作用。", "",
        "单独舵效降低10%也不可忽视：12 m/s纯深度和耦合分别13.98/14.26 s越切向速度界。15 m/s与18 m/s同一失配均未越现有界限。18 m/s耦合所有配置完成24 s，而18 m/s纯深度的组合失配仍在5.38 s越界；风险随速度和机动共同变化，不能归纳为“越快越危险”或“越快越稳”。", "",
        "质量±10%、阻尼±10%、推力±10%、延迟由3步变为1/5步、时间常数减半、舵效增加10%均未触发现有诊断界限；这些结论仅适用于所测幅度、参考和24 s时窗。零越界不能代表没有性能退化，尤其要审查沿程位置误差和饱和。", "",
        "18 m/s直线揭示独立的推进能力问题：基线匀速配平需最大推力的94.99%；阻尼+10%和推力增益−10%分别需104.49%/105.54%，已超过推进上限。两例推力命令100%时间饱和，实际推力在95.25%的子步处于上限；24 s北向位置落后9.10/11.04 m，北向RMSE6.218/7.269 m（matched仅0.223 m）。它们没有触发诊断界限，因为本协议没有沿程位置界，且速度误差尚不足2 m/s。应将其标为能力不足导致的持续跟踪损失，不能叫作动态稳定性通过。", "",
        "匹配模型也不等于零跟踪误差：基线12/15 m/s水平位置向量RMSE1.749/1.026 m；18 m/s耦合位置向量RMSE1.605 m，推力命令饱和99.2%。而直线12/15 m/s匹配位置RMSE约1.3 mm，故这类工况任何小偏差都可能产生很大的VR。必须同时读RMSE、偏差、首越界和执行器饱和，不能仅按VR排序。全部192例QP均求解成功，观测到的边界事件不是QP失败回退造成。", "",
        "这些大幅机动包含命令饱和和时变状态，可用于配对因果比较与压力诊断；它们本身不构成局部线性IMC或SVD结论的验证。频域部分应使用围绕同一局部工作点的小激励、独立验证记录与明确的输入/误差量纲。", "",
        "## 交付文件与复现", "", "- paired_protocol.json：执行前冻结协议、版本和哈希。", "- paired_summary.json / .csv：192例完整指标、首越界、QP失败、命令/实际饱和。", "- paired_allfactor_common_window.json：每工况统一最短前缀指标。", "- paired_results/*.npz：全部0.02 s状态/参考/输出/误差/实际执行器及0.1 s命令和QP状态；对应json为配置与运行元数据。", "- paired_matrix.png/.pdf、paired_mechanisms.png/.pdf：矩阵和机制对比图。", "- plant_harness.py：可复用植物；paired_matrix.py：原始控制器实验；paired_report.py：图表和数据口径检查。", "", "复现：在工作目录配置原仓库与依赖后执行 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 .venv-gs12/bin/python gs12_followup/paired_matrix.py --workers 2`；已有同哈希数据可加 `--resume`。随后执行 `.venv-gs12/bin/python gs12_followup/paired_report.py`。"]
    (ROOT/"paired_notes.md").write_text("\n".join(lines)+"\n")
    print(json.dumps({"cases":len(cases),"failures":len(failures),"qp_failures":sum(c["qp_failures"] for c in cases),"figures":["paired_matrix.png","paired_mechanisms.png"]}))


if __name__=="__main__":
    main()
