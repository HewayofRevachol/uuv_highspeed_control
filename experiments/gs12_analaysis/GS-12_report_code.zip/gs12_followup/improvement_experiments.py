"""Evaluate research controller alternatives with causal measured-rate observer."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

from plant_harness import (Plant, PlantConfig, SCALE, REPO, reference,
    diagnostic_values, BatchedUUVModel, CondensedActuatorMPC, ActuatorAwareCpuDynamics)
from improved_controller import make_second_order_controller, CausalRateObserver

ROOT = Path(__file__).resolve().parent


def run_case(config, speed, ref_function, duration, method, stop=True):
    torch.set_num_threads(1)
    model = BatchedUUVModel("cpu")
    use25 = method in ("order25", "fins25") or method.startswith("order25_pitch")
    if use25:
        mpc = make_second_order_controller(model, REPO, fins_only=method == "fins25")
        observer = CausalRateObserver(fins_only=method == "fins25")
        if method.startswith("order25_pitch"):
            mpc.attitude_pitch_weight = float(method.removeprefix("order25_pitch"))
    else:
        mpc = CondensedActuatorMPC(model, 1, horizon=35, dt=.1)
        if method == "conservative22":
            mpc.dynamics = ActuatorAwareCpuDynamics(.1, .85, 2.)
        elif method != "baseline22":
            raise ValueError(method)
    plant = Plant(speed, config)
    mpc.previous[:] = model.tensor(plant.actual/SCALE)
    mpc.plan[:] = mpc.previous[:, None]
    estimated_rate = np.zeros(3)
    arrays = {k: [] for k in ("time", "state", "reference", "error", "output", "command",
        "actual", "qp_ok", "estimated_rate", "diagnostic", "one_step_body_error")}
    violation = None
    for k in range(round(duration/.1)):
        z22 = plant.controller_state()
        z = np.r_[z22, estimated_rate] if use25 else z22
        refs = ref_function((k+np.arange(1, 36))*.1)
        command, ok = mpc.solve(model.tensor(z)[None], model.tensor(refs)[None])
        command = command[0].numpy()
        expected = mpc.dynamics.evaluate(z[None, None], (command/SCALE)[None, None])[0][0, 0]
        old_actual, old_queue = (plant.actual/SCALE).copy(), (plant.queue[:3]/SCALE).copy()
        for j in range(5):
            plant.step(command)
            now = (k*5+j+1)*.02
            ref, output = ref_function(now), plant.output()
            error = ref-output
            error[3:5] = np.arctan2(np.sin(error[3:5]), np.cos(error[3:5]))
            diagnostics = diagnostic_values(output, ref)
            for key, value in (("time", now), ("state", plant.x.copy()),
                ("reference", ref), ("error", error), ("output", output),
                ("command", command.copy()), ("actual", plant.actual.copy()),
                ("qp_ok", bool(ok[0])), ("estimated_rate", estimated_rate.copy()),
                ("diagnostic", diagnostics)):
                arrays[key].append(value)
            exceeded = np.abs(diagnostics) > [8, 5, 2, np.deg2rad(40)]
            if violation is None and np.any(exceeded):
                violation = {"time_s": now, "kinds": [name for name, flag in zip(
                    ("lateral", "depth", "speed", "pitch"), exceeded) if flag]}
            if not np.isfinite(plant.x).all() or (stop and violation):
                break
        if j == 4:
            arrays["one_step_body_error"].append(plant.x[5:10]-expected[5:10])
            if use25:
                estimated_rate = observer.estimate(old_actual, plant.actual/SCALE, old_queue, command/SCALE)
        if not np.isfinite(plant.x).all() or (stop and violation):
            break
    arrays = {k: np.asarray(v) for k, v in arrays.items()}
    metrics = {"method": method, "config": asdict(config), "speed_mps": speed,
        "duration_s": float(arrays['time'][-1]), "first_violation": violation,
        "qp_failed_substeps": int(np.sum(~arrays['qp_ok'])),
        "RMSE": np.sqrt(np.mean(arrays['error']**2, axis=0)).tolist(),
        "mean_error": arrays['error'].mean(axis=0).tolist(),
        "body_one_step_RMSE": np.sqrt(np.mean(arrays['one_step_body_error']**2, axis=0)).tolist(),
        "command_saturation_fraction": np.mean((arrays['command']/SCALE >= 1-1e-6) |
            (arrays['command']/SCALE <= np.array([0,-1,-1])+1e-6), axis=0).tolist(),
        "actual_saturation_fraction": np.mean((arrays['actual']/SCALE >= 1-1e-6) |
            (arrays['actual']/SCALE <= np.array([0,-1,-1])+1e-6), axis=0).tolist()}
    return metrics, arrays


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=ROOT/'improvement_results')
    args = parser.parse_args()
    args.out.mkdir(exist_ok=False)
    methods = ['baseline22', 'conservative22', 'order25']
    configs = {'matched': PlantConfig(), 'combined': PlantConfig(elevator=.9,rudder=.9,order='second_all'),
        'combined_tau_shift': PlantConfig(elevator=.9,rudder=.9,order='second_all',tau_scale=(1.2,1.2,1.2))}
    jobs = [(speed, maneuver, plant_name, method) for speed in (12.,15.,18.)
            for maneuver in ('depth','coupled') for plant_name in configs for method in methods]
    protocol = {'jobs': jobs, 'duration_s':24., 'shared_time_reference':True,
        'design_choice':'order25 nominal gain=1,tau=1,delay3; no true plant rate/tau/gain read',
        'observer':'two actuator position observations + previous issued command + three queued commands; nominal second-order model',
        'variants_frozen_before_results':True,
        'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                         [Path(__file__),ROOT/'improved_controller.py',ROOT/'plant_harness.py']}}
    (args.out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    results=[]
    for speed,maneuver,plant_name,method in jobs:
        ref=lambda t: reference(t,speed,maneuver)
        metrics, arrays=run_case(configs[plant_name],speed,ref,24.,method)
        name=f'{speed:g}_{maneuver}_{plant_name}_{method}'
        metrics.update(name=name,maneuver=maneuver,plant_name=plant_name)
        np.savez_compressed(args.out/f'{name}.npz',**arrays)
        (args.out/f'{name}.json').write_text(json.dumps(metrics,indent=2)+'\n')
        results.append(metrics)
        print(json.dumps({'case':name,'duration':metrics['duration_s'],'violation':metrics['first_violation']}),flush=True)
    # Every controller comparison uses the common prefix on the SAME plant.
    for result in results:
        group=[r for r in results if (r['speed_mps'],r['maneuver'],r['plant_name'])==
               (result['speed_mps'],result['maneuver'],result['plant_name'])]
        end=min(r['duration_s'] for r in group)
        a=np.load(args.out/f"{result['name']}.npz")
        mask=a['time']<=end+1e-9
        result['common_end_s']=end
        result['common_RMSE']=np.sqrt(np.mean(a['error'][mask]**2,axis=0)).tolist()
    (args.out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__=='__main__':
    main()
