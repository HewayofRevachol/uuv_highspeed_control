"""Independent propagation/observer checks for the research prototype."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plant_harness import Plant, PlantConfig, SCALE, REPO
from improved_controller import SecondOrderDynamics, CausalRateObserver, make_second_order_controller
import numpy as np
import pytest
from simulator.batch_mpc import BatchedUUVModel
from simulator.rti_symbolic import AUGMENTED_NX


def test_second_order_transition_and_causal_observer():
    rng = np.random.default_rng(95121)
    for fins_only in (False, True):
        plant = Plant(15., PlantConfig(order="second_fins" if fins_only else "second_all"))
        dynamics = SecondOrderDynamics(fins_only=fins_only)
        observer = CausalRateObserver(fins_only=fins_only)
        for _ in range(12):
            state = np.r_[plant.controller_state(), plant.rate/SCALE]
            old_actual, old_queue = plant.actual/SCALE, plant.queue[:3]/SCALE
            command = np.array([rng.uniform(.4, .9), rng.uniform(-.3, .3), rng.uniform(-.3, .3)])
            expected = dynamics.evaluate(state[None, None], command[None, None])[0][0, 0]
            for _ in range(5):
                plant.step(command*SCALE)
            actual = np.r_[plant.controller_state(), plant.rate/SCALE]
            np.testing.assert_allclose(actual, expected, rtol=1e-10, atol=1e-10)
            estimate = observer.estimate(old_actual, plant.actual/SCALE, old_queue, command)
            np.testing.assert_allclose(estimate, plant.rate/SCALE, rtol=1e-9, atol=1e-10)


def test_jacobians_match_finite_differences():
    dynamics = SecondOrderDynamics()
    plant = Plant(15., PlantConfig(order="second_all"))
    z, u = np.r_[plant.controller_state(), .02, -.01, .04], np.array([.65, .1, -.1])
    f, a, b = dynamics.evaluate(z[None, None], u[None, None])
    h = 1e-5
    for i in range(25):
        dz = np.zeros(25); dz[i] = h
        fp = dynamics.evaluate((z+dz)[None, None], u[None, None])[0][0, 0]
        fm = dynamics.evaluate((z-dz)[None, None], u[None, None])[0][0, 0]
        np.testing.assert_allclose((fp-fm)/(2*h), a[0, 0, :, i], rtol=1e-5, atol=2e-8)
    for i in range(3):
        du = np.zeros(3); du[i] = h
        fp = dynamics.evaluate(z[None, None], (u+du)[None, None])[0][0, 0]
        fm = dynamics.evaluate(z[None, None], (u-du)[None, None])[0][0, 0]
        np.testing.assert_allclose((fp-fm)/(2*h), b[0, 0, :, i], rtol=1e-5, atol=2e-8)


def test_private_controller_does_not_modify_repository_dimension():
    model = BatchedUUVModel("cpu")
    controller = make_second_order_controller(model, REPO)
    assert controller.states.shape == (1, 36, 25)
    from aav_mpc import condensed_mpc
    assert AUGMENTED_NX == 22
    assert condensed_mpc.AUGMENTED_NX == 22
    assert condensed_mpc.CondensedActuatorMPC(model, 1).states.shape[-1] == 22


def test_reject_unsupported_discretization_and_singular_observer():
    with pytest.raises(ValueError, match="singular"):
        CausalRateObserver(fin_tau_scale=.5)
    with pytest.raises(ValueError, match="20ms"):
        SecondOrderDynamics(dt=.11)
    with pytest.raises(ValueError, match=".03s"):
        SecondOrderDynamics(fin_tau_scale=.2)
