"""Frozen SVD-informed hybrid development candidate: 18 stress + 4 FRF runs.

Uses an unmodified prior runner loaded into a private module, replacing only
its predictor factory and observer. Never edits existing source/provenance.
"""
import os
for _name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):
    os.environ[_name]="1"

import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
from dataclasses import asdict
from functools import lru_cache
import hashlib
import importlib.util
import json
from pathlib import Path
import time

import numpy as np
from plant_harness import PlantConfig,reference,REPO,SCALE as CONTROL_SCALE
from hybrid_controller import make_hybrid_controller,ThrustRateObserver,validate_hybrid
from frequency_identification import reference as frequency_reference,OMEGA,PHASE,SETTLE,PERIOD,SCALE

ROOT=Path(__file__).resolve().parent
CONFIGS={"matched":PlantConfig(),"combined":PlantConfig(elevator=.9,rudder=.9,order="second_all"),
         "combined_tau_shift":PlantConfig(elevator=.9,rudder=.9,order="second_all",tau_scale=(1.2,)*3)}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@lru_cache(maxsize=1)
def private_runner():
    path=ROOT/"improvement_experiments.py"
    spec=importlib.util.spec_from_file_location("gs12_hybrid_private_runner",path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    def factory(model,repo,fins_only=False):
        assert not fins_only
        return make_hybrid_controller(model,repo)
    def observer(fins_only=False):
        assert not fins_only
        return ThrustRateObserver()
    module.make_second_order_controller=factory
    module.CausalRateObserver=observer
    return module


def run_hybrid_case(config,speed,ref_function,duration,stop=True):
    meta,arrays=private_runner().run_case(config,speed,ref_function,duration,"order25",stop)
    meta["method"]="hybrid25"
    return meta,arrays


def run_one(job):
    kind,speed,maneuver,plant_name,axis,out=job
    out=Path(out)
    start=time.perf_counter()
    if kind=="stress":
        name=f"{speed:g}_{maneuver}_{plant_name}_hybrid25"
        meta,arrays=run_hybrid_case(CONFIGS[plant_name],speed,lambda t:reference(t,speed,maneuver),24.)
        meta.update(name=name,maneuver=maneuver,plant_name=plant_name)
    else:
        name=f"hybrid25_axis{axis}"
        amplitude=0. if axis<0 else .006
        meta,arrays=run_hybrid_case(CONFIGS["combined"],15.,
            lambda t:frequency_reference(t,15.,axis,amplitude),SETTLE+2*PERIOD,False)
        assert len(arrays["time"])==7200 and np.isfinite(arrays["state"]).all()
        idx=slice(4,None,5)
        times=arrays["time"][idx];refs=arrays["reference"][idx]
        arrays.update(time_s=times,error_normalized=arrays["error"][idx][:,[1,2,5]]/SCALE,
            input_normalized=np.column_stack((refs[:,1],refs[:,2]-20.,refs[:,5]-15.))/SCALE)
        meta.update(name=name,axis=axis,amplitude_per_line_normalized=amplitude)
    meta["wall_s_not_realtime_benchmark"]=time.perf_counter()-start
    np.savez_compressed(out/f"{name}.npz",**arrays)
    (out/f"{name}.json").write_text(json.dumps(meta,indent=2)+"\n")
    return meta


def stress_summary(out):
    results=[]
    previous=ROOT/"improvement_results"
    for speed in (12.,15.,18.):
        for maneuver in ("depth","coupled"):
            for plant_name in CONFIGS:
                stem=f"{speed:g}_{maneuver}_{plant_name}"
                meta=json.loads((out/f"{stem}_hybrid25.json").read_text())
                a=np.load(out/f"{stem}_hybrid25.npz")
                c=np.load(previous/f"{stem}_conservative22.npz")
                n=min(len(a["time"]),len(c["time"]))
                assert np.array_equal(a["time"][:n],c["time"][:n])
                assert np.array_equal(a["reference"][:n],c["reference"][:n])
                def stats(data,length):
                    error=data["error"][:length]
                    return dict(RMSE=np.sqrt(np.mean(error**2,axis=0)).tolist(),
                                mean_error=error.mean(0).tolist(),variance=error.var(0).tolist(),
                                diagnostic_RMSE=np.sqrt(np.mean(data["diagnostic"][:length]**2,axis=0)).tolist())
                hs,cs=stats(a,n),stats(c,n)
                denominator=np.asarray(cs["variance"])
                meta["comparison_conservative22"]=dict(common_end_s=float(a["time"][n-1]),
                    hybrid=hs,conservative=cs,VR=[float(v/d) if d>1e-12 else None for v,d in zip(hs["variance"],denominator)],
                    position_RMSE_ratio=float(np.linalg.norm(hs["RMSE"][:3])/np.linalg.norm(cs["RMSE"][:3])),
                    conservative_first_violation=json.loads((previous/f"{stem}_conservative22.json").read_text())["first_violation"])
                all_data={method:np.load(previous/f"{stem}_{method}.npz")
                          for method in ("baseline22","conservative22","order25")}
                all_data["hybrid25"]=a
                shared=min(len(d["time"]) for d in all_data.values())
                for d in all_data.values():
                    assert np.array_equal(d["reference"][:shared],a["reference"][:shared])
                meta["four_method_common"]=dict(end_s=float(a["time"][shared-1]),
                    methods={method:stats(d,shared) for method,d in all_data.items()})
                results.append(meta)
    (out/"summary.json").write_text(json.dumps(results,indent=2)+"\n")
    return results


def estimate_frf(out):
    baseline=np.load(out/"hybrid25_axis-1.npz")["error_normalized"]
    h=np.empty((2,len(OMEGA),3,3),complex)
    distortions=[];distortion_rms=[];metas=[]
    for axis in range(3):
        data=np.load(out/f"hybrid25_axis{axis}.npz")
        metas.append(json.loads((out/f"hybrid25_axis{axis}.json").read_text()))
        t=data["time_s"];e=data["error_normalized"]-baseline;u=data["input_normalized"][:,axis]
        for period in range(2):
            mask=(t>SETTLE+period*PERIOD+1e-8)&(t<=SETTLE+(period+1)*PERIOD+1e-8)
            tt,ee,uu=t[mask],e[mask],u[mask]
            assert len(tt)==640
            ph=np.exp(-1j*tt[:,None]*OMEGA)
            E=2/len(tt)*ph.T@ee;U=2/len(tt)*ph.T@uu
            np.testing.assert_allclose(np.abs(U),.006,atol=1e-12,rtol=1e-9)
            h[period,:,:,axis]=E/U[:,None]
            if period==1:
                centered=ee-ee.mean(0)
                residual=centered-np.real(np.exp(1j*tt[:,None]*OMEGA)@E)
                distortions.append(float(np.linalg.norm(residual)/np.linalg.norm(centered)))
                distortion_rms.append(dict(centered_output=np.sqrt(np.mean(centered**2,axis=0)).tolist(),
                                           unexcited=np.sqrt(np.mean(residual**2,axis=0)).tolist()))
    H=h[1]
    left,singular,vh=np.linalg.svd(H)
    v=vh.conj().transpose(0,2,1)[:,:,0]
    for k in range(len(v)):v[k]*=np.exp(-1j*np.angle(v[k,np.argmax(np.abs(v[k]))]))
    convergence=np.linalg.norm(h[1]-h[0],axis=(1,2))/np.maximum(np.linalg.norm(H,axis=(1,2)),1e-12)
    previous={"baseline22":ROOT/"frequency_data/frf_v15_combined_a0.006.npz",
              "conservative22":ROOT/"improvement_frequency_results/frf_conservative22.npz",
              "order25":ROOT/"improvement_frequency_results/frf_order25.npz"}
    comparators={}
    for name,path in previous.items():
        data=np.load(path);np.testing.assert_array_equal(data["omega_radps"],OMEGA)
        g=data["H"];sv=np.linalg.svd(g,compute_uv=False)
        comparators[name]=dict(sha256=sha(path),sigma_max=sv[:,0].tolist(),
            axis_column_norms=np.linalg.norm(g,axis=1).tolist(),
            sigma_ratio_hybrid_over_comparator=(singular[:,0]/sv[:,0]).tolist(),
            axis_column_norm_ratio_hybrid_over_comparator=(np.linalg.norm(H,axis=1)/np.linalg.norm(g,axis=1)).tolist())
    peak=int(np.argmax(singular[:,0]))
    result=dict(method="hybrid25",speed_mps=15.,plant=asdict(CONFIGS["combined"]),scale=SCALE.tolist(),
        omega_radps=OMEGA.tolist(),H=dict(real=H.real.tolist(),imag=H.imag.tolist()),
        singular_values=singular.tolist(),axis_column_norms=np.linalg.norm(H,axis=1).tolist(),
        right_max_vector_abs=np.abs(v).tolist(),right_max_vector_phase_deg=np.rad2deg(np.angle(v)).tolist(),
        peak_index=peak,peak_sigma=float(singular[peak,0]),peak_omega_radps=float(OMEGA[peak]),
        period_relative_change=convergence.tolist(),unexcited_output_rms_fraction_by_input=distortions,
        unexcited_output_rms_details=distortion_rms,comparators=comparators,
        qp_failed_substeps=sum(m["qp_failed_substeps"] for m in metas),
        command_saturation_fraction_by_input=[m["command_saturation_fraction"] for m in metas],
        actual_saturation_fraction_by_input=[m["actual_saturation_fraction"] for m in metas],
        first_violations=[m["first_violation"] for m in metas],
        validation_limit="Development regression on previously studied plants and seven frequencies, no independent half-amplitude validation, no unsampled-frequency claim")
    np.savez_compressed(out/"frf_hybrid25.npz",H=H,H_period1=h[0],omega_radps=OMEGA,singular_values=singular,
                        right_max_vector=v,period_relative_change=convergence)
    (out/"frequency_summary.json").write_text(json.dumps(result,indent=2)+"\n")
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=ROOT/"hybrid_results")
    parser.add_argument("--workers",type=int,default=2,choices=[1,2])
    args=parser.parse_args();args.out.mkdir(exist_ok=False)
    jobs=[("stress",speed,maneuver,plant_name,None,str(args.out)) for speed in (12.,15.,18.)
          for maneuver in ("depth","coupled") for plant_name in CONFIGS]
    jobs += [("frequency",15.,None,"combined",axis,str(args.out)) for axis in (-1,0,1,2)]
    source_files=[Path(__file__),ROOT/"hybrid_controller.py",ROOT/"improved_controller.py",
        ROOT/"improvement_experiments.py",ROOT/"plant_harness.py",ROOT/"frequency_identification.py",
        REPO/"aav_mpc/condensed_mpc.py",REPO/"simulator/rti_symbolic.py"]
    protocol=dict(candidate="hybrid25",choice="nominal second-order thrust + conservative first-order fins(gain .85,tau x2); fixed delay3 and unchanged MPC objective",
        rationale="Existing SVD/FRF showed order25 improves speed but worsens depth; conservative22 improves peak depth but retains speed gain. This candidate was proposed AFTER those results.",
        validation_role="Development regression; these plants, maneuvers and frequencies are not unseen held-out tests",
        observer="Only two measured normalized thrust positions plus prior issued thrust and 3 observed queued thrusts; fin rates always zero; no hidden true rate/tau/parameters",
        implementation="Unmodified improvement_experiments.py loaded privately; only predictor factory and observer replaced; same loop, initial trim, references, diagnostic/stop rules",
        jobs=jobs,stress_configs={name:asdict(config) for name,config in CONFIGS.items()},stress_duration_s=24.,
        frequency_speed_mps=15.,frequency_plant="combined",frequency_axes=[-1,0,1,2],
        frequency_amplitude_per_line_normalized=.006,frequency_scale=SCALE.tolist(),
        frequency_omega_radps=OMEGA.tolist(),frequency_phases_rad=PHASE.tolist(),
        frequency_duration_s=144.,frequency_estimation_window_s=[80.,144.],frequency_convergence_window_s=[16.,80.],
        comparison="Same-reference common time prefixes against conservative22 and against all four controllers; scan all seven measured frequencies",
        source_sha256={str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path.relative_to(REPO)):sha(path) for path in source_files})
    (args.out/"protocol.json").write_text(json.dumps(protocol,indent=2)+"\n")
    validation=validate_hybrid()
    (args.out/"validation.json").write_text(json.dumps(validation,indent=2)+"\n")
    print(json.dumps({"validation":validation}),flush=True)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run_one,job) for job in jobs]
        for i,future in enumerate(as_completed(futures),1):
            result=future.result()
            print(json.dumps(dict(completed=i,name=result["name"],duration_s=result["duration_s"],first_violation=result["first_violation"])),flush=True)
    stress=stress_summary(args.out);frf=estimate_frf(args.out)
    print(json.dumps(dict(stress_cases=len(stress),violations=sum(c["first_violation"] is not None for c in stress),
                         peak_sigma=frf["peak_sigma"],period_change=max(frf["period_relative_change"]))),flush=True)


if __name__=="__main__":main()
