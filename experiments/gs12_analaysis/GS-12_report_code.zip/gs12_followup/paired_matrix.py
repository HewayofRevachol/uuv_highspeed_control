"""Frozen 192-case paired nonlinear closed-loop experiment; run from workdir.

Example: .venv-gs12/bin/python gs12_followup/paired_matrix.py --workers 2
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plant_harness import PlantConfig, OUTPUTS, REPO, parity_check, reference, run_closed_loop

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "paired_results"
SPEEDS = [12., 15., 18.]
MANEUVERS = ["straight", "horizontal", "depth", "coupled"]


def configurations():
    base = PlantConfig()
    result = {"matched": base}
    for factor in ("mass", "damping", "thrust"):
        for value in (.9, 1.1):
            result[f"{factor}_{value:g}"] = replace(base, **{factor: value})
    for value in (.9, 1.1):
        result[f"fin_{value:g}"] = replace(base, elevator=value, rudder=value)
    for steps in (1, 5):
        result[f"delay_{steps}"] = replace(base, delay_steps=(steps,)*3)
    for value in (.5, 2.):
        result[f"tau_{value:g}"] = replace(base, tau_scale=(value,)*3)
    result["second_all"] = replace(base, order="second_all")
    result["second_fins"] = replace(base, order="second_fins")
    result["fin_0.9_second_all"] = replace(base, elevator=.9, rudder=.9, order="second_all")
    return result


def case_id(speed, maneuver, name):
    return f"v{speed:g}_{maneuver}_{name}"


def run_one(job):
    speed, maneuver, name, config = job
    identifier = case_id(speed, maneuver, name)
    result = run_closed_loop(config, speed, lambda t: reference(t, speed, maneuver))
    result["meta"].update({"id": identifier, "maneuver": maneuver, "name": name})
    np.savez_compressed(OUT / f"{identifier}.npz", **result["arrays"])
    (OUT / f"{identifier}.json").write_text(json.dumps(result["meta"], indent=2)+"\n")
    return result["meta"]


def metrics():
    summaries = []
    for speed in SPEEDS:
        for maneuver in MANEUVERS:
            design = np.load(OUT/f"{case_id(speed, maneuver, 'matched')}.npz")
            for name in configurations():
                identifier = case_id(speed, maneuver, name)
                actual = np.load(OUT/f"{identifier}.npz")
                meta = json.loads((OUT/f"{identifier}.json").read_text())
                n = min(len(design["time"]), len(actual["time"]))
                if not (np.array_equal(design["reference"][:n], actual["reference"][:n]) and
                        np.array_equal(design["time"][:n], actual["time"][:n])):
                    raise AssertionError("paired time/reference mismatch")
                ed, ea = design["error"][:n], actual["error"][:n]
                vd, va = np.var(ed, axis=0), np.var(ea, axis=0)
                diagnostic = actual["diagnostic"][:n]
                dm = design["diagnostic"][:n]
                meta.update({"design_pair": case_id(speed, maneuver, "matched"),
                    "paired_substeps": n, "window_start_s": .02, "window_end_s": float(actual["time"][n-1]),
                    "VR": [float(a/d) if d>1e-12 else None for a,d in zip(va,vd)],
                    "variance": va.tolist(), "design_variance": vd.tolist(),
                    "RMSE": np.sqrt(np.mean(ea**2, axis=0)).tolist(),
                    "design_RMSE": np.sqrt(np.mean(ed**2, axis=0)).tolist(),
                    "mean_error": np.mean(ea, axis=0).tolist(),
                    "design_mean_error": np.mean(ed, axis=0).tolist(),
                    "max_abs_error": np.max(np.abs(ea), axis=0).tolist(),
                    "diagnostic_RMSE": np.sqrt(np.mean(diagnostic**2, axis=0)).tolist(),
                    "design_diagnostic_RMSE": np.sqrt(np.mean(dm**2, axis=0)).tolist(),
                    "diagnostic_max_abs": np.max(np.abs(diagnostic), axis=0).tolist(),
                    "tracking_energy_ratio": float(np.sum(ea[:, :3]**2)/np.sum(ed[:, :3]**2))
                                              if np.sum(ed[:, :3]**2)>1e-12 else None})
                if name == "matched" and meta["one_step_max_abs_state_error"] > 1e-9:
                    raise AssertionError("matched transition is not matched")
                summaries.append(meta)
    (ROOT/"paired_summary.json").write_text(json.dumps({"output_order": OUTPUTS,
        "diagnostic_order": ["lateral_m", "depth_m", "tangent_speed_mps", "absolute_pitch_rad"],
        "cases": summaries}, indent=2)+"\n")
    fields = ["id", "speed_mps", "maneuver", "name", "duration_observed_s", "violation",
              "window_end_s", "qp_failures", "true_straight_trim_fraction", "tracking_energy_ratio"]
    fields += [f"{key}_{output}" for key in ("RMSE", "mean_error", "VR") for output in OUTPUTS]
    fields += [f"{key}_{channel}" for key in ("command_sat", "actual_sat") for channel in ("thrust", "elevator", "rudder")]
    with (ROOT/"paired_summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for meta in summaries:
            row = {field: meta[field] for field in fields if field in meta}
            row["violation"] = ",".join(meta["first_diagnostic_limit_violation"]["kinds"]) if meta["first_diagnostic_limit_violation"] else ""
            for key in ("RMSE", "mean_error", "VR"):
                row.update({f"{key}_{output}": value for output, value in zip(OUTPUTS, meta[key])})
            for key, source in (("command_sat", "command_saturation_fraction"), ("actual_sat", "actual_saturation_fraction_substeps")):
                row.update({f"{key}_{channel}":value for channel,value in zip(("thrust", "elevator", "rudder"),meta[source])})
            writer.writerow(row)
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=2, choices=[1,2])
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    jobs = [(speed, maneuver, name, config) for speed in SPEEDS for maneuver in MANEUVERS
            for name, config in configurations().items()]
    sources = ["aav_mpc/condensed_mpc.py", "simulator/rti_symbolic.py", "simulator/batch_mpc.py", "simulator/model.py", "aav_mpc/h15_target_domain.py"]
    protocol = {"purpose": "deterministic nonlinear paired finite records, not statistical repetitions or H15 acceptance",
        "repo_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "source_sha256": {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in sources},
        "analysis_sha256": {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ("paired_matrix.py", "plant_harness.py")},
        "python":platform.python_version(), "platform":platform.platform(),
        "packages":{p:importlib.metadata.version(p) for p in ("numpy", "torch", "scipy", "osqp", "casadi")},
        "speeds_mps":SPEEDS, "maneuvers":MANEUVERS,
        "configurations_relative_to_MISMATCHED_PLANT":{name:asdict(c) for name,c in configurations().items()},
        "case_count":len(jobs), "duration_s":24., "controller":"original CondensedActuatorMPC, fixed gains and weights", "horizon":35,
        "controller_period_s":.1, "plant_substep_s":.02, "integrator":"RK4 all cases",
        "prediction_actuator":"first order, 3 substeps delay, baseline tau .10/.08/.08 s",
        "initial_state":"[0,0,20,0,0,speed,0,0,0,0] shared by all plants of each speed",
        "initial_actuator_queue_plan":"shared baseline straight trim, not each true plant's trim",
        "control_scale":[1500000., float(np.pi/4), float(np.pi/4)],
        "noise":0, "current":0, "randomization":False,
        "reference_equations": {
            "straight":"N=V*t+1.2*(1-cos(.5*t)), E=0, D=20; VN=V+.6*sin(.5*t)",
            "horizontal":"N=V*t, E=6*(1-cos(.7*t)), D=20",
            "depth":"N=V*t, E=0, D=20+2.4*(1-cos(.84*t))",
            "coupled":"N=V*t, E=6*(1-cos(.7*t)), D=20+2.4*(1-cos(.84*t))",
            "all":"velocity=analytic position derivative; yaw=atan2(VE,VN); pitch=-atan2(VD,hypot(VN,VE)); immutable time reference and exact future preview"},
        "termination":"first substep exceeding |lateral|8m, |depth error|5m, |tangent speed error|2m/s, |absolute pitch|40deg or nonfinite; include violation sample",
        "paired_metrics":"common time prefix at .02s, no burn-in; error=reference-output; centered population VR, denominator<=1e-12 => null",
        "second_order":"source semi-implicit critically damped recurrence omega=1/max(tau,.03), no clipping; all versus fins-only separate",
        "saturation":"command every .1s and actual actuator EVERY .02s; near upper/lower bound within 1e-6 normalized",
        "excluded":["RL", "FSP", "residual compensation", "progress feedback", "midpoint integration", "per-plant retrim"],
        "parity_check":parity_check()}
    protocol_path = ROOT/"paired_protocol.json"
    if protocol_path.exists() and args.resume:
        prior = json.loads(protocol_path.read_text())
        if prior["analysis_sha256"] != protocol["analysis_sha256"] or prior["source_sha256"] != protocol["source_sha256"]:
            raise RuntimeError("resume source hash mismatch")
    else:
        if any(OUT.glob("*.npz")):
            raise RuntimeError("existing results require --resume")
        protocol_path.write_text(json.dumps(protocol, indent=2)+"\n")
    pending = [job for job in jobs if not(args.resume and (OUT/f"{case_id(*job[:3])}.json").exists() and (OUT/f"{case_id(*job[:3])}.npz").exists())]
    print(json.dumps({"frozen_protocol":str(protocol_path), "pending_cases":len(pending)}), flush=True)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run_one, job) for job in pending]
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            print(json.dumps({"completed":i, "id":result["id"], "end_s":result["duration_observed_s"],
                              "violation":result["first_diagnostic_limit_violation"]}), flush=True)
    summaries = metrics()
    print(json.dumps({"completed_total":len(summaries),
                      "violations":sum(c["first_diagnostic_limit_violation"] is not None for c in summaries)}), flush=True)


if __name__ == "__main__":
    main()
