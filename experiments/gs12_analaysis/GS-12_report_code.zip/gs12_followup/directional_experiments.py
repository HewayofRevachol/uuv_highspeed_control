"""Replay measured complex SVD directions through actual nonlinear MPC.

Small amplitude validates linear superposition; larger amplitude probes
constraints. Controller variants and input norm are fixed within each pair.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import numpy as np
from plant_harness import PlantConfig
from improvement_experiments import run_case

ROOT=Path(__file__).resolve().parent
SCALES=np.array([8.,5.,2.])


def reference(t,omega,vector,amplitude,speed=15.):
    t=np.asarray(t)
    ph=np.exp(1j*omega*t[...,None])
    val=amplitude*np.real(ph*vector)*SCALES
    deriv=amplitude*np.real(1j*omega*ph*vector)*SCALES
    int_speed=amplitude*SCALES[2]*np.real(vector[2]*(np.exp(1j*omega*t)-1)/(1j*omega))
    north=speed*t+int_speed; east=val[...,0]; depth=20+val[...,1]
    vn=speed+val[...,2];ve=deriv[...,0];vd=deriv[...,1]
    pitch=-np.arctan2(vd,np.hypot(vn,ve));yaw=np.arctan2(ve,vn)
    return np.stack([north,east,depth,pitch,yaw,vn,ve,vd],axis=-1)


def main():
    out=ROOT/'directional_results';out.mkdir(exist_ok=False)
    specs=[]
    for config in ('combined','second_order'):
        source=ROOT/f'frequency_data/frf_v15_{config}_a0.006.npz'
        data=np.load(source);k=int(np.argmax(data['singular_values'][:,0]))
        H=data['H'][k];U,s,Vh=np.linalg.svd(H);omega=float(data['omega_radps'][k])
        for direction,index in [('max',0),('min',2)]:
            if config=='second_order' and direction=='min':continue
            v=Vh.conj().T[:,index];v*=np.exp(-1j*np.angle(v[np.argmax(abs(v))]))
            specs.append({'config':config,'direction':direction,'omega':omega,
                'vector_real':v.real.tolist(),'vector_imag':v.imag.tolist(),
                'predicted_error_real':(H@v).real.tolist(),'predicted_error_imag':(H@v).imag.tolist(),
                'predicted_gain':float(s[index]),'frf_source':source.name,
                'frf_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
    protocol={'normalization':SCALES.tolist(),'small_amplitude':.006,'challenge_amplitude':.06,
        'duration_s':80.,'settle_s':16.,'fit_window_s':[48.,80.],
        'note':'peak is maximum sampled within measured band; not a global H-infinity norm',
        'directions':specs,'methods':['baseline22','conservative22','order25'],
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    results=[]
    for spec in specs:
        cfg=PlantConfig(order='second_all',elevator=.9 if spec['config']=='combined' else 1.,
                        rudder=.9 if spec['config']=='combined' else 1.)
        v=np.array(spec['vector_real'])+1j*np.array(spec['vector_imag'])
        for amplitude in (.006,.06):
            ref=lambda t: reference(t,spec['omega'],v,amplitude)
            for method in protocol['methods']:
                metrics,arrays=run_case(cfg,15.,ref,80.,method)
                name=f"{spec['config']}_{spec['direction']}_a{amplitude:g}_{method}"
                metrics.update(name=name,config_name=spec['config'],direction=spec['direction'],
                    amplitude=amplitude,omega=spec['omega'],predicted_small_gain=spec['predicted_gain'])
                if metrics['duration_s']>=80.-1e-9:
                    mask=arrays['time']>48.+1e-9
                    t=arrays['time'][mask]
                    e=arrays['error'][mask][:,[1,2,5]]/SCALES
                    response=2/len(t)*np.exp(-1j*spec['omega']*t)@e/amplitude
                    # Compare at 0.1s sampling, the empirical FRF convention.
                    mask100=mask & np.isclose(np.mod(arrays['time'],.1),0,atol=1e-8)
                    indices=np.arange(4,len(arrays['time']),5)
                    indices=indices[arrays['time'][indices]>48.+1e-9]
                    tt=arrays['time'][indices];ee=arrays['error'][indices][:,[1,2,5]]/SCALES
                    response100=2/len(tt)*np.exp(-1j*spec['omega']*tt)@ee/amplitude
                    predicted=np.array(spec['predicted_error_real'])+1j*np.array(spec['predicted_error_imag'])
                    metrics.update(measured_gain=float(np.linalg.norm(response100)),
                        measured_response_real=response100.real.tolist(),measured_response_imag=response100.imag.tolist(),
                        base_frf_relative_error=float(np.linalg.norm(response100-predicted)/max(np.linalg.norm(predicted),1e-12)),
                        fit_window_s=[48.,80.])
                np.savez_compressed(out/f'{name}.npz',**arrays)
                (out/f'{name}.json').write_text(json.dumps(metrics,indent=2)+'\n')
                results.append(metrics)
                print(json.dumps({'case':name,'duration':metrics['duration_s'],'gain':metrics.get('measured_gain'),
                    'violation':metrics['first_violation']}),flush=True)
    for result in results:
        group=[r for r in results if (r['config_name'],r['direction'],r['amplitude'])==
               (result['config_name'],result['direction'],result['amplitude'])]
        end=min(r['duration_s'] for r in group);a=np.load(out/f"{result['name']}.npz")
        result['common_end_s']=end
        result['common_RMSE']=np.sqrt(np.mean(a['error'][a['time']<=end+1e-9]**2,axis=0)).tolist()
    (out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__=='__main__':main()
