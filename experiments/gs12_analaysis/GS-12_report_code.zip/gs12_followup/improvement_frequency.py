"""Rescan the measured FRF band after the GS-12 predictor modifications.

Exactly eight runs: three independent reference axes and a zero-excitation
baseline for each of conservative22 and order25, at 15 m/s on combined plant.
Uses the existing closed-loop runner without changing its production source.
"""
import os
for _name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_name] = "1"

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from frequency_identification import reference, OMEGA, PHASE, SETTLE, PERIOD, SCALE
from improvement_experiments import run_case
from plant_harness import PlantConfig, SCALE as CONTROL_SCALE

ROOT = Path(__file__).resolve().parent
METHODS = ("conservative22", "order25")
SPEED = 15.
AMPLITUDE = .006
DURATION = SETTLE + 2 * PERIOD
CONFIG = PlantConfig(elevator=.9, rudder=.9, order="second_all")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def complex_dump(value):
    value = np.asarray(value)
    return {"real": value.real.tolist(), "imag": value.imag.tolist()}


def run_one(task):
    method, axis, out = task
    out = Path(out)
    tag = f"{method}_axis{axis}"
    target, metadata = out / f"{tag}.npz", out / f"{tag}.json"
    if target.exists() and metadata.exists():
        return json.loads(metadata.read_text())
    amplitude = 0. if axis == -1 else AMPLITUDE
    started = time.perf_counter()
    ref_function = lambda t: reference(t, SPEED, axis, amplitude)
    meta, arrays = run_case(CONFIG, SPEED, ref_function, DURATION, method, stop=False)
    assert arrays["time"].size == round(DURATION / .02), "incomplete run"
    assert np.isfinite(arrays["state"]).all(), "nonfinite state"
    # Compare to the original FRF's 10 Hz, end-of-controller-period samples.
    idx = slice(4, None, 5)
    times, refs = arrays["time"][idx], arrays["reference"][idx]
    assert np.allclose(times, .1 * np.arange(1, len(times) + 1), atol=1e-10, rtol=0.)
    errors = arrays["error"][idx][:, [1, 2, 5]] / SCALE
    inputs = np.column_stack((refs[:, 1], refs[:, 2] - 20., refs[:, 5] - SPEED)) / SCALE
    np.savez_compressed(target, **arrays, time_s=times, error_normalized=errors,
                        input_normalized=inputs, omega_radps=OMEGA, scale=SCALE)
    meta.update(tag=tag, axis=axis, amplitude_per_line_normalized=amplitude,
                filename=target.name, seconds=time.perf_counter() - started,
                max_abs_pitch_deg=float(np.rad2deg(np.abs(arrays["state"][:, 3]).max())),
                max_thrust_fraction=float((arrays["command"] / CONTROL_SCALE)[:, 0].max()))
    metadata.write_text(json.dumps(meta, indent=2) + "\n")
    return meta


def estimate(out):
    out = Path(out)
    original_path = ROOT / "frequency_data/frf_v15_combined_a0.006.npz"
    original = np.load(original_path) if original_path.exists() else None
    base_h = original["H"] if original is not None else None
    base_s = np.linalg.svd(base_h, compute_uv=False) if base_h is not None else None
    base_v = original["right_max_vector"] if original is not None else None
    if original is not None:
        np.testing.assert_allclose(original["omega_radps"], OMEGA, atol=0., rtol=0.)
    results = []
    for method in METHODS:
        h = np.empty((2, len(OMEGA), 3, 3), complex)
        baseline = np.load(out / f"{method}_axis-1.npz")["error_normalized"]
        distortion = []
        distortion_rms = []
        metas = []
        for axis in range(3):
            d = np.load(out / f"{method}_axis{axis}.npz")
            metas.append(json.loads((out / f"{method}_axis{axis}.json").read_text()))
            t, e, u = d["time_s"], d["error_normalized"] - baseline, d["input_normalized"][:, axis]
            for period in range(2):
                mask = (t > SETTLE + period * PERIOD + 1e-8) & (t <= SETTLE + (period + 1) * PERIOD + 1e-8)
                tt, ee, uu = t[mask], e[mask], u[mask]
                assert len(tt) == 640
                projection = np.exp(-1j * tt[:, None] * OMEGA)
                E = 2 / len(tt) * projection.T @ ee
                U = 2 / len(tt) * projection.T @ uu
                np.testing.assert_allclose(np.abs(U), AMPLITUDE, rtol=1e-9, atol=1e-12)
                h[period, :, :, axis] = E / U[:, None]
                if period == 1:
                    residual = ee - ee.mean(0) - np.real(np.exp(1j * tt[:, None] * OMEGA) @ E)
                    distortion.append(float(np.linalg.norm(residual) / max(np.linalg.norm(ee - ee.mean(0)), 1e-15)))
                    distortion_rms.append(dict(input_axis=axis,
                        centered_output_normalized_rms=np.sqrt(np.mean((ee-ee.mean(0))**2, axis=0)).tolist(),
                        unexcited_normalized_rms=np.sqrt(np.mean(residual**2, axis=0)).tolist()))
        H = h[1]
        left, singular, vh = np.linalg.svd(H)
        v = vh.conj().transpose(0, 2, 1)[:, :, 0]
        for k in range(len(v)):
            v[k] *= np.exp(-1j * np.angle(v[k, np.argmax(np.abs(v[k]))]))
        _, singular1, vh1 = np.linalg.svd(h[0])
        period_direction_overlap = np.abs(np.einsum("fi,fi->f", vh[:, 0].conj(), vh1[:, 0]))
        gap = singular[:, 0] - singular[:, 1]
        matrix_period_difference = np.linalg.norm(H-h[0], ord=2, axis=(1, 2))
        convergence = np.linalg.norm(h[1] - h[0], axis=(1, 2)) / np.maximum(np.linalg.norm(h[1], axis=(1, 2)), 1e-12)
        peak = int(np.argmax(singular[:, 0]))
        result = dict(method=method, speed_mps=SPEED, plant=asdict(CONFIG),
            amplitude_per_line_normalized=AMPLITUDE, scale=SCALE.tolist(),
            omega_radps=OMEGA.tolist(), H=complex_dump(H), H_period1=complex_dump(h[0]),
            singular_values=singular.tolist(), right_max_vector=complex_dump(v),
            right_max_vector_abs=np.abs(v).tolist(),
            right_max_vector_phase_deg=np.rad2deg(np.angle(v)).tolist(),
            peak_index=peak, peak_omega_radps=float(OMEGA[peak]), peak_sigma=float(singular[peak, 0]),
            period_relative_change=convergence.tolist(),
            top_singular_value_gap=gap.tolist(),
            top_singular_value_relative_gap=(gap/singular[:, 0]).tolist(),
            top_direction_period_overlap=period_direction_overlap.tolist(),
            period_spectral_difference=matrix_period_difference.tolist(),
            period_spectral_difference_over_top_gap=(matrix_period_difference/gap).tolist(),
            unexcited_output_rms_fraction_by_input=distortion,
            unexcited_output_rms_details=distortion_rms,
            baseline_removed=True, baseline_mean_normalized=baseline[-640:].mean(0).tolist(),
            qp_failures=sum(m["qp_failed_substeps"] for m in metas) // 5,
            command_saturation_fraction_by_input=[m["command_saturation_fraction"] for m in metas],
            actual_saturation_fraction_by_input=[m["actual_saturation_fraction"] for m in metas],
            violations=[m["first_violation"] for m in metas],
            analysis_script_sha256=sha(__file__),
            interpretation="Maximum over seven sampled frequencies; no unsampled-band or robust-stability claim",
            validation_limit="No independent half-amplitude FRF rescan for these controller variants")
        if base_h is not None:
            same_direction_gain = np.linalg.norm(np.einsum("fij,fj->fi", H, base_v), axis=1)
            baseline_on_new_direction = np.linalg.norm(np.einsum("fij,fj->fi", base_h, v), axis=1)
            result.update(original_baseline_frf_sha256=sha(original_path),
                baseline22_sigma_max=base_s[:, 0].tolist(),
                sigma_max_ratio_to_baseline22=(singular[:, 0] / base_s[:, 0]).tolist(),
                gain_on_old_max_direction=same_direction_gain.tolist(),
                gain_ratio_on_old_max_direction=(same_direction_gain / base_s[:, 0]).tolist(),
                baseline22_gain_on_new_max_direction=baseline_on_new_direction.tolist(),
                new_direction_overlap_with_old=np.abs(np.einsum("fi,fi->f", v.conj(), base_v)).tolist())
        np.savez_compressed(out / f"frf_{method}.npz", H=H, H_period1=h[0], omega_radps=OMEGA,
                            singular_values=singular, right_max_vector=v, period_relative_change=convergence)
        results.append(result)
    (out / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    lines = ["15 m/s、combined 植物；两个控制器各三独立轴加零激励，共 8 例。每例 144 s，16 s 过渡后两段 64 s，最终 FRF 使用 80–144 s。", "",
             "| 控制器 | 已测频带最大 σ | 频率 rad/s | 最敏感输入的绝对分量 east/depth/VN | 最大周期间变化 |", "| --- | ---: | ---: | --- | ---: |"]
    for r in results:
        lines.append(f"| {r['method']} | {r['peak_sigma']:.8f} | {r['peak_omega_radps']:.6f} | {np.array(r['right_max_vector_abs'][r['peak_index']]).round(5).tolist()} | {max(r['period_relative_change']):.3g} |")
    lines.extend(["", "两种控制器均无 QP 失败、命令/实际执行器饱和或诊断越界。", "",
                  "| 频率 rad/s | conservative22 / baseline22 的 σmax 比 | order25 / baseline22 的 σmax 比 |", "| --- | ---: | ---: |"])
    for k, omega in enumerate(OMEGA):
        lines.append(f"| {omega:.6f} | {results[0]['sigma_max_ratio_to_baseline22'][k]:.6f} | {results[1]['sigma_max_ratio_to_baseline22'][k]:.6f} |")
    lines.extend(["", "二阶预测器的已测最大增益增大约 34.05%，最坏方向仍几乎是纯 depth，未转移到新的控制方向。它在速度方向的改善不能替代对 depth 方向恶化的报告。保守一阶降低已测最大值约 14.34%，但前六个频点的最大增益均增大，属于频带与通道间的取舍。", "",
                  "最高频处三个奇异值：", ""])
    for r in results:
        k = r["peak_index"]
        lines.append(f"- {r['method']}: {np.array(r['singular_values'][k]).round(8).tolist()}；首二间隔 {r['top_singular_value_gap'][k]:.8f}，相对间隔 {100*r['top_singular_value_relative_gap'][k]:.3f}%。")
    lines.extend(["", "所有频点最大方向的两周期复内积绝对值均大于 .9999999999，说明方向对残留瞬态稳定；这不是测量噪声或幅值变化下的稳定性保证。", "",
                  "conservative22 的横向输入非激励频率残差占中心化输出 RMS 的约 20%，超过先前建议的 10% 局部线性筛查；其余 conservative 输入约 4.67%、0.048%，order25 三轴约 6.99%、3.60%、0.039%。因此保守控制器的完整矩阵只作当前有限幅值的探索性响应。详细分量和绝对 RMS 见 summary.json。", "",
                  "幅值与原扫描一致；这两种新控制器未另做半幅 FRF 扫描。这里只比较七个已测频点，不能排除未测频率的新峰或推断鲁棒稳定性。"])
    (out / "results.md").write_text("\n".join(lines) + "\n")
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "improvement_frequency_results")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--estimate-only", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True, parents=True)
    if not args.estimate_only:
        if any(args.out.glob("*_axis*.npz")):
            raise FileExistsError("Use a fresh --out for new simulations, or --estimate-only for existing data")
        protocol = dict(speed_mps=SPEED, plant=asdict(CONFIG), methods=METHODS,
            axes=[-1, 0, 1, 2], axis_minus1="zero excitation baseline",
            amplitude_per_line_normalized=AMPLITUDE, scale=SCALE.tolist(),
            omega_radps=OMEGA.tolist(), phases_rad=PHASE.tolist(), duration_s=DURATION,
            settle_s=SETTLE, period_s=PERIOD, plant_sample_s=.02, frf_sample_s=.1,
            final_frf_window_s=[80., 144.], convergence_window_s=[16., 80.],
            source_sha256={p.name: sha(p) for p in [Path(__file__), ROOT / "frequency_identification.py",
                ROOT / "improvement_experiments.py", ROOT / "improved_controller.py", ROOT / "plant_harness.py"]})
        (args.out / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
        tasks = [(method, axis, str(args.out)) for method in METHODS for axis in (-1, 0, 1, 2)]
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(run_one, task) for task in tasks]
            for future in as_completed(futures):
                result = future.result()
                print(json.dumps({k: result[k] for k in ("tag", "duration_s", "first_violation", "seconds")}), flush=True)
    for result in estimate(args.out):
        print(json.dumps({k: result[k] for k in ("method", "peak_sigma", "peak_omega_radps", "period_relative_change", "unexcited_output_rms_fraction_by_input")}), flush=True)


if __name__ == "__main__":
    main()
