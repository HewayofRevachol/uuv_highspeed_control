"""Visualize complete controller comparisons and retained negative results."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
methods=['baseline22','conservative22','order25']
labels=['Original 22-state','Conservative 22-state','Second-order 25-state']
colors=['#b03a2e','#1e8449','#2471a3']
summary=json.loads((root/'improvement_results/summary.json').read_text())
fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
freqpaths=[root/'frequency_data/frf_v15_combined_a0.006.npz',
           root/'improvement_frequency_results/frf_conservative22.npz',
           root/'improvement_frequency_results/frf_order25.npz']
for p,label,c in zip(freqpaths,labels,colors):
    d=np.load(p);ax[0,0].plot(d['omega_radps'],d['singular_values'][:,0],'o-',label=label,color=c)
ax[0,0].set(xlabel='Frequency (rad/s)',ylabel='Max normalized error gain',
    title='15 m/s combined plant: all measured frequencies')
ax[0,0].legend(fontsize=8)
for i,(method,label,c) in enumerate(zip(methods,labels,colors)):
    vals=[sum(r['method']==method and r['plant_name']==p and r['first_violation'] is None
              for r in summary) for p in ['matched','combined','combined_tau_shift']]
    ax[0,1].bar(np.arange(3)+(i-1)*.23,vals,width=.23,label=label,color=c)
ax[0,1].set_xticks(np.arange(3),['Matched first order','Combined mismatch','Combined + tau x1.2'])
ax[0,1].set(ylabel='No diagnostic crossing / 6 cases',ylim=(0,6.5),title='54 finite-horizon tests; counts are not probabilities')
for method,label,c in zip(methods,labels,colors):
    d=np.load(root/f'improvement_results/15_coupled_combined_{method}.npz')
    ax[1,0].plot(d['time'],np.rad2deg(d['state'][:,3]),label=label,color=c)
    ax[1,1].plot(d['time'],d['error'][:,2],label=label,color=c)
ax[1,0].axhline(40,c='gray',ls='--',lw=.8)
ax[1,0].set(xlabel='Time (s)',ylabel='Actual pitch (deg)',title='15 m/s coupled maneuver, same true plant')
ax[1,1].set(xlabel='Time (s)',ylabel='Depth error (m)',title='Curves stop at first diagnostic crossing')
for a in ax.flat:a.grid(alpha=.2)
fig.suptitle('GS-12: predictor structure and controller tuning involve tradeoffs',fontsize=13)
fig.savefig(root/'controller_tradeoffs.png',dpi=180)
fig.savefig(root/'controller_tradeoffs.pdf')

directions=json.loads((root/'directional_results/summary.json').read_text())
tuning=json.loads((root/'direction_tuning_results/summary.json').read_text())
rows=[]
for r in directions:
    if r['amplitude']==.006:
        rows.append({k:r.get(k) for k in ['name','measured_gain','base_frf_relative_error','first_violation']})
aggregate={'improvement_no_crossing':{
    method:{p:sum(r['method']==method and r['plant_name']==p and not r['first_violation'] for r in summary)
            for p in ('matched','combined','combined_tau_shift')} for method in methods},
    'direction_small_amplitude':rows,
    'pitch_weight_development_screen':[{k:r.get(k) for k in ['method','gain','first_violation']} for r in tuning]}
(root/'improvement_aggregate.json').write_text(json.dumps(aggregate,indent=2)+'\n')
print(json.dumps(aggregate,indent=2))
