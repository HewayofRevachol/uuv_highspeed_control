"""Package delivered research artifacts without caches, logs or dependencies."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'gs12_delivery'
DATA_GROUPS = {
    'GS-12_paired_data.zip': ['paired_results'],
    'GS-12_frequency_data.zip': ['frequency_data'],
    'GS-12_controller_maneuver_data.zip': [
        'improvement_results', 'directional_results', 'direction_tuning_results'],
    'GS-12_controller_frequency_hybrid_data.zip': [
        'improvement_frequency_results', 'hybrid_results'],
}
EXPECTED_RAW = dict(paired_results=192, frequency_data=82, improvement_results=54,
                    directional_results=18, direction_tuning_results=3,
                    improvement_frequency_results=8, hybrid_results=25)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    groups = {}
    for name, directories in DATA_GROUPS.items():
        groups[name] = sorted(p for d in directories for p in (ROOT/d).rglob('*')
                              if p.is_file() and '__pycache__' not in p.parts)
    source = sorted(p for p in ROOT.iterdir() if p.is_file() and
                    p.suffix in {'.py', '.md', '.json', '.csv', '.txt', '.png', '.pdf'}
                    and p.name != 'delivery_manifest.json')
    source += sorted((ROOT/'frozen_sources').glob('*.py'))
    groups['GS-12_report_code.zip'] = source
    raw_counts = {d: len([p for p in (ROOT/d).rglob('*.npz')
                         if not p.name.startswith('frf_')]) for d in EXPECTED_RAW}
    assert raw_counts == EXPECTED_RAW, raw_counts
    manifest = {
        'repo_commit': '926b7ac4b8559c9b2261d72e689649f6080a34b3',
        'raw_closed_loop_runs': raw_counts,
        'raw_total': sum(raw_counts.values()),
        'interpretation': 'Counts include repeated conditions; not independent scenarios',
        'file_sha256_by_archive': {
            name: {str(p.relative_to(ROOT.parent)): digest(p) for p in paths}
            for name, paths in groups.items()},
        'manifest_note': 'This manifest is added to code archive; its own hash is excluded',
    }
    manifest_path = ROOT/'delivery_manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    groups['GS-12_report_code.zip'].append(manifest_path)
    archives = []
    for name, paths in groups.items():
        target = OUT/name
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in paths:
                archive.write(path, path.relative_to(ROOT.parent))
        with zipfile.ZipFile(target) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(paths)
        archives.append(dict(name=name, bytes=target.stat().st_size,
                             sha256=digest(target), files=len(paths)))
    (OUT/'archive_checksums.json').write_text(json.dumps(archives, indent=2)+'\n')
    print(json.dumps({'raw_total': sum(raw_counts.values()), 'archives': archives}, indent=2))


if __name__ == '__main__':
    main()
