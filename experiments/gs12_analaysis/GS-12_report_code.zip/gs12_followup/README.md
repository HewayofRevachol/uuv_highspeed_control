# GS-12 进一步分析：交付与复现

先读 `GS-12_进一步分析.md`；方法细节见 `paired_notes.md`、`frequency_notes.md`、`method_audit.md`。这些是确定性仿真诊断和研究原型，未修改生产控制器或训练模型。

## 环境与目录

使用 Python 3.11、macOS arm64，依赖按本次环境锁定在 `requirements-analysis.txt`（与上轮锁定文件相同）。其他平台若需不同 PyTorch 构建，应记录版本差异。仓库固定为 `926b7ac4b8559c9b2261d72e689649f6080a34b3`，不要以最新分支替代。

脚本按自身位置查找仓库，必须保持两个目录同级；以下命令均在它们的共同父目录执行：

```text
工作目录/
  uuv_highspeed_control/
  gs12_followup/
  .venv-gs12/
```

```sh
git clone https://github.com/HewayofRevachol/uuv_highspeed_control.git
git -C uuv_highspeed_control checkout 926b7ac4b8559c9b2261d72e689649f6080a34b3
python3.11 -m venv .venv-gs12
.venv-gs12/bin/python -m pip install -r gs12_followup/requirements-analysis.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
```

已有该提交的仓库时跳过克隆；代码包不含仓库、Python环境或模型权重。

## 五个附件包如何合并

代码/报告包含 `gs12_followup` 根目录的脚本、报告、图、协议/汇总文件及 `frozen_sources`，不含以下原始结果目录。只从代码包开始，按下节顺序运行即可生成全部结果。

四个数据包分别包含：

- 配对数据：`gs12_followup/paired_results/`。
- 基础频域数据：`gs12_followup/frequency_data/`。
- 控制器机动/方向数据：`gs12_followup/improvement_results/`、`directional_results/`、`direction_tuning_results/`。
- 控制器频域/分通道数据：`gs12_followup/improvement_frequency_results/`、`hybrid_results/`。

均解压至同一个工作目录，使内容合并进同一个 `gs12_followup/`。数据包内部的协议和汇总保留原位置。重绘已有图需先解压对应数据包；完整重算建议在新的代码包副本中进行，不与已交付原始数据混放。

## 按依赖顺序完整重算

以下使用默认输出目录；不要给没有命令行参数的脚本添加 `--out`。原型测试先运行，之后各组使用相同仓库和环境。

```sh
# 原型传播、Jacobian、因果速率重建及生产控制器隔离检查
.venv-gs12/bin/python -m pytest -q gs12_followup/test_improved_controller.py

# 192条逐项配对闭环；脚本同时执行植物独立传播核查
.venv-gs12/bin/python gs12_followup/paired_matrix.py --workers 2
.venv-gs12/bin/python gs12_followup/paired_report.py

# 基础频域：82条闭环，13组全幅矩阵+10组半幅矩阵，含13条零激励
.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 15 --configs matched fin_0p9 delay5 tau2 fin_tau2 second_order combined --baseline --workers 2
.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 15 --configs matched fin_0p9 delay5 tau2 second_order combined --amplitude .003 --workers 2
.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 12 18 --configs matched second_order combined --baseline --workers 2
.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 12 18 --configs matched combined --amplitude .003 --workers 2
.venv-gs12/bin/python gs12_followup/frequency_report.py

# 三控制器54条大幅机动、18条SVD单频方向、3条pitch权重开发对照
.venv-gs12/bin/python gs12_followup/improvement_experiments.py
.venv-gs12/bin/python gs12_followup/directional_experiments.py
.venv-gs12/bin/python gs12_followup/direction_tuning.py

# 保守22与完整二阶25：各3轴+零激励，共8条完整频带辨识
.venv-gs12/bin/python gs12_followup/improvement_frequency.py --workers 2
.venv-gs12/bin/python gs12_followup/improvement_report.py

# 推力二阶+双舵保守一阶开发候选：18条机动+3轴及零激励，共22条
.venv-gs12/bin/python gs12_followup/hybrid_experiments.py --workers 2
# 再做3轴半幅检查，并生成混合候选图表
.venv-gs12/bin/python gs12_followup/hybrid_half_amplitude.py
.venv-gs12/bin/python gs12_followup/hybrid_report.py
```

混合候选共25条记录：18条机动、3轴全幅及零激励、3轴半幅；半幅复用相同候选的零激励基线。混合候选需要前面的54条机动结果、基础FRF及两候选FRF用于相同时间窗比较，不能单独从空数据目录运行。绘图/汇总脚本使用默认目录；其他实验即使支持 `--out`，改用新目录后也需相应调整下游读取位置。

## 缓存、重跑与输出覆盖

| 脚本 | 已有结果时的行为 |
|---|---|
| `paired_matrix.py` | 有 `.npz` 时必须加 `--resume`；同时核对分析与仓库源文件哈希。已有成对JSON/NPZ跳过，其余重算。没有 `--resume` 不覆盖原始记录。 |
| `frequency_identification.py` | 自动复用同名JSON+NPZ，**不检查脚本/参数哈希**；改变模型或代码后必须使用新 `--out` 或先另存整个旧目录。`--estimate-only`仅从现有数据估计。 |
| `improvement_experiments.py` | 默认目录必须不存在；可用 `--out 新目录`。 |
| `directional_experiments.py` / `direction_tuning.py` | 固定输出目录必须不存在，无CLI参数；重跑前另存旧目录。 |
| `improvement_frequency.py` | 支持 `--out`；若已有轴向NPZ则拒绝新仿真，已有完整数据可加 `--estimate-only`。 |
| `hybrid_experiments.py` | 支持 `--out`；目录必须不存在。 |
| `hybrid_half_amplitude.py` | 无CLI参数，固定读取 `hybrid_results`；`hybrid_results/half_amplitude` 必须不存在。 |
| 各 `*_report.py`、估计/汇总阶段 | 覆盖所读目录中的派生JSON/CSV及根目录图表/分项笔记；不会自动重写主报告。 |

自动缓存不是独立重复实验；应保留协议中的版本、参数和原始数据。已有数据包中的空目录或仅含协议的目录，也会触发使用 `exist_ok=False` 的脚本拒绝运行；需要先改名保留旧目录。不要混用修改前后的结果再生成同一汇总。

## 源文件版本与数值溯源

`frozen_sources/` 保存运行时相关源码快照，供哈希核对；不要直接从该子目录执行，因为脚本的相对目录推导不同。交付版 `improved_controller.py` 后续增加非法时间步/时间常数及奇异观测器拒绝检查，`improvement_experiments.py` 增加显式 `order25_pitch*` 开发分支；这些增补不改变原有默认方法的方程、权重或参数。原始运行协议仍保留当时哈希，不改写成当前文件哈希。

`frozen_sources/frequency_identification.py` 与 `improvement_frequency_results/protocol.json` 记录的依赖哈希 `b3d6abaf…` 完全匹配。交付版 `44a81f1…` 仅追加由 `H v / σ` 得出的左最大奇异向量及JSON/NPZ字段，不改变参考、闭环运行、H、奇异值或右向量；详见 `frequency_source_provenance.json`。方向重放引用的两个旧FRF文件也已保存在 `frequency_data/frozen_direction_inputs/`，其完整字节哈希与方向协议一致；当前FRF仅增加左向量NPZ成员，原有数组完全一致。基础频域每例JSON没有逐例脚本哈希，`frequency_protocol.json` 的脚本哈希是交付/重分析版本，不能解释为所有原始运行均采用完全相同源码字节。

首批仅双舵时间常数加倍的数据曾使用 `tau2` 名称，后明确重命名为 `fin_tau2` 并另行运行全通道 `tau2`；交付脚本分别支持两者。按轴排序的失真统计和左向量字段均从原始数据重新汇总。依赖快照、运行协议和当前交付源码承担不同溯源角色。混合候选另有 `hybrid_results/source_snapshots/` 和 `frozen_manifest.json`，保存其四个脚本快照与结果哈希。

## 频域解释边界

FRF为几何一致的三个参考自由度到三个跟踪误差的经验矩阵，输入/输出共同按 `[8 m, 5 m, 2 m/s]` 归一化，误差为参考减实际。参考含3.5 s未来预览，不能直接当作标准单自由度反馈灵敏度、已验证IMC或论文RSI。

七个频点为 `2π/64 × [2,4,6,8,12,16,24] rad/s`，范围 `.19635–2.35619 rad/s`。每条记录144 s，前16 s不用；两个64 s整数周期窗口检验重复性，第二窗口估计复响应。多正弦实际共同最短周期为32 s。最大全部仅指这七个频点，不能宣称全频共振峰或稳定裕度。

基础矩阵的半幅检查覆盖10组，未覆盖12/18 m/s的 `second_order` 和15 m/s额外 `fin_tau2`；保守22与完整二阶25的新增FRF没有独立半幅重测。应同时看周期变化、半幅变化、未激励输出RMS占比与命令约束，周期重复不证明线性。复右奇异向量必须保留相对相位；18 m/s组合的奇异值近重根，不应认定唯一最危险方向。

混合候选是在已有SVD与控制器结果之后提出的开发回归，不是独立留出验证。所有实验均为同一水动力模型下的确定性仿真；未覆盖测量噪声、海流、随机化、实艇误差与实时预算。
