"""Bounded development screen: pitch-weight changes on identified depth direction."""
import json
from pathlib import Path
import numpy as np
from directional_experiments import reference, SCALES
from improvement_experiments import run_case
from plant_harness import PlantConfig

root=Path(__file__).resolve().parent
out=root/'direction_tuning_results';out.mkdir(exist_ok=False)
d=np.load(root/'frequency_data/frf_v15_combined_a0.006.npz')
k=np.argmax(d['singular_values'][:,0]);w=float(d['omega_radps'][k])
_,_,vh=np.linalg.svd(d['H'][k]);v=vh.conj().T[:,0];v*=np.exp(-1j*np.angle(v[np.argmax(abs(v))]))
methods=['order25_pitch30','order25_pitch300','order25_pitch1000']
protocol={'stage':'development only, selected after baseline/order25 direction findings',
    'methods_frozen_before_screen':methods,'omega_radps':w,'amplitude':.006,'duration_s':80.,
    'vector_real':v.real.tolist(),'vector_imag':v.imag.tolist(),
    'scope':'same actual plant, same 25-state nominal parameters; change only pitch cost weight'}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
results=[]
for method in methods:
    ref=lambda t:reference(t,w,v,.006)
    metrics,a=run_case(PlantConfig(elevator=.9,rudder=.9,order='second_all'),15.,ref,80.,method)
    if metrics['duration_s']>=80-1e-8:
        indices=np.arange(4,len(a['time']),5);indices=indices[a['time'][indices]>48+1e-8]
        response=2/len(indices)*np.exp(-1j*w*a['time'][indices])@(a['error'][indices][:,[1,2,5]]/SCALES)/.006
        metrics['gain']=float(np.linalg.norm(response))
    results.append(metrics)
    np.savez_compressed(out/f'{method}.npz',**a)
    print(json.dumps({'method':method,'gain':metrics.get('gain'),'violation':metrics['first_violation']}),flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
