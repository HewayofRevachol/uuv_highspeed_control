"""Generate figures, validation summaries, and Chinese notes from raw FRFs."""
from pathlib import Path
import json
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from frequency_identification import estimate,ROOT
OUT=ROOT/'gs12_followup/frequency_data'
BASE=ROOT/'gs12_followup'
LABEL={'matched':'matched','fin_0p9':'fin gain 0.9','delay5':'delay 0.10 s','tau2':'all actuator tau x2','fin_tau2':'fin tau x2','second_order':'second order','combined':'fin 0.9 + second order'}
COLORS={'matched':'black','fin_0p9':'#2ca02c','delay5':'#ff7f0e','tau2':'#e377c2','fin_tau2':'#8c564b','second_order':'#9467bd','combined':'#d62728'}
AXES=['East / 8 m','Depth / 5 m','North speed / 2 m/s']

def h(r):return np.asarray(r['H']['real'])+1j*np.asarray(r['H']['imag'])
def v(r):return np.asarray(r['right_max_vector']['real'])+1j*np.asarray(r['right_max_vector']['imag'])
def main():
 rows=estimate(OUT)
 lookup={(r['speed'],r['config'],r['amplitude_per_line_normalized']):r for r in rows}
 validation=[];peaks=[]
 for r in rows:
  speed,cfg,amp=r['speed'],r['config'],r['amplitude_per_line_normalized']
  if amp!=.006:continue
  H=h(r);V=v(r);i=r['peak_index'];nom=lookup[(speed,'matched',.006)];H0=h(nom)
  same=np.linalg.norm(np.einsum('kij,kj->ki',H,V),axis=1)/np.maximum(np.linalg.norm(np.einsum('kij,kj->ki',H0,V),axis=1),1e-12)
  half=lookup.get((speed,cfg,.003));delta=None
  if half:delta=np.linalg.norm(H-h(half),axis=(1,2))/np.maximum(np.linalg.norm(h(half),axis=(1,2)),1e-12)
  item=dict(speed=speed,config=cfg,omega_radps=r['omega_radps'],same_direction_mismatch_over_matched=same.tolist(),half_amplitude_relative_matrix_change=None if delta is None else delta.tolist(),period_relative_change=r['period_relative_change'],unexcited_output_rms_fraction_by_input=r['unexcited_output_rms_fraction_by_input'])
  validation.append(item)
  peaks.append(dict(speed=speed,config=cfg,peak_omega=r['omega_radps'][i],peak_sigma=r['peak_sigma'],direction_magnitudes=r['right_max_vector_abs'][i],direction_phases_deg=r['right_max_vector_phase_deg'][i],same_direction_ratio_at_peak=float(same[i]),relative_top_singular_gap=float((r['singular_values'][i][0]-r['singular_values'][i][1])/r['singular_values'][i][0]),peak_all_singular_values=r['singular_values'][i],half_peak_right_vector_abs_overlap=None if half is None else float(abs(np.vdot(V[i],v(half)[i]))),period_max=max(r['period_relative_change']),half_max=None if delta is None else float(max(delta)),distortion_max=max(r['unexcited_output_rms_fraction_by_input'])))
 (OUT/'frequency_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
 (OUT/'frequency_peak_summary.json').write_text(json.dumps(peaks,indent=2)+'\n')
 with (OUT/'frequency_peak_summary.csv').open('w') as f:
  fields=['speed','config','peak_omega','peak_sigma','same_direction_ratio_at_peak','period_max','half_max','distortion_max','relative_top_singular_gap','half_peak_right_vector_abs_overlap'];w=csv.DictWriter(f,fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in peaks)
 fig,axs=plt.subplots(1,3,figsize=(13,4.3),sharey=True)
 for ax,speed in zip(axs,[12,15,18]):
  for r in rows:
   if r['speed']==speed and r['amplitude_per_line_normalized']==.006:
    ax.plot(r['omega_radps'],np.asarray(r['singular_values'])[:,0],marker='o',markersize=3,color=COLORS[r['config']],label=LABEL[r['config']])
  ax.set_title(f'{speed:g} m/s straight trim');ax.set_xlabel('Excited frequency (rad/s)');ax.grid(alpha=.25);ax.set_xlim(.15,2.45)
 axs[0].set_ylabel('Largest normalized reference-error singular value')
 axs[1].legend(fontsize=7,loc='upper left');fig.suptitle('Nonlinear MPC empirical FRF; sampled band only, 3.5 s preview');fig.tight_layout();fig.savefig(BASE/'frequency_singular_values.png',dpi=180);plt.close(fig)
 sel=lookup[(15.,'combined',.006)];H=h(sel);omega=sel['omega_radps']
 fig,axs=plt.subplots(3,3,figsize=(10,8),sharex=True)
 for o in range(3):
  for i in range(3):
   axs[o,i].plot(omega,np.abs(H[:,o,i]),'o-');axs[o,i].grid(alpha=.25)
   if o==0:axs[o,i].set_title('Reference '+AXES[i])
   if i==0:axs[o,i].set_ylabel('Error '+AXES[o])
   if o==2:axs[o,i].set_xlabel('rad/s')
 fig.suptitle('15 m/s, fin gain 0.9 + second-order actuators: |H|\nCross-axis terms include finite-amplitude nonlinear coupling');fig.tight_layout();fig.savefig(BASE/'frequency_matrix_magnitudes.png',dpi=180);plt.close(fig)
 fig,axs=plt.subplots(1,3,figsize=(12,4),sharey=True)
 for ax,speed in zip(axs,[12.,15.,18.]):
  for cfg,marker in [('second_order','o'),('combined','s')]:
   r=lookup[(speed,cfg,.006)];i=r['peak_index'];magn=np.array(r['right_max_vector_abs'])[i];positions=np.arange(3)+(.12 if cfg=='combined' else -.12)
   ax.bar(positions,magn,width=.24,color=COLORS[cfg],label=LABEL[cfg]);ax.set_xticks(np.arange(3),['East','Depth','North speed']);ax.set_title(f'{speed:g} m/s, sampled maximum'+('\nCombined: nearly repeated singular values' if speed==18 else ''));ax.grid(axis='y',alpha=.25)
 axs[0].set_ylabel('Magnitude of unit-norm right singular vector');axs[1].legend(fontsize=8);fig.tight_layout();fig.savefig(BASE/'frequency_sensitive_directions.png',dpi=180);plt.close(fig)
 fig,axs=plt.subplots(2,3,figsize=(12,7),sharex=True)
 for cfg in ['matched','fin_0p9','second_order','combined']:
  rr=lookup[(15.,cfg,.006)];HH=h(rr)
  for axis in range(3):
   axs[0,axis].plot(rr['omega_radps'],np.abs(HH[:,axis,axis]),'o-',markersize=3,color=COLORS[cfg],label=LABEL[cfg])
   axs[1,axis].plot(rr['omega_radps'],np.angle(HH[:,axis,axis],deg=True),'o-',markersize=3,color=COLORS[cfg])
 for axis in range(3):
  axs[0,axis].set_title(AXES[axis]);axs[0,axis].grid(alpha=.25);axs[1,axis].grid(alpha=.25);axs[1,axis].set_xlabel('rad/s');axs[1,axis].set_ylim(-185,185)
 axs[0,0].set_ylabel('Diagonal |H|');axs[1,0].set_ylabel('Principal phase (degrees)');axs[0,1].legend(fontsize=8);fig.suptitle('15 m/s empirical diagonal FRFs; e = reference - actual, exp(+j omega t)');fig.tight_layout();fig.savefig(BASE/'frequency_diagonal_bode.png',dpi=180);plt.close(fig)
 # Append exact complex directions and phases; plotting magnitudes alone does not define an excitation.
 lines=['# GS-12 局部频域辨识与 SVD','',
 '本节针对几何一致的三维参考生成器到跟踪误差的经验频响，使用真实非线性艇体与仓库 CondensedActuatorMPC；并未把八个相关参考量当成八个独立输入。结论限于所测直航工作点、小幅激励和 0.19635–2.35619 rad/s 的七个离散频率。采样带最大值不等于全频域共振峰或稳定裕度。','',
 '## 实验与有效性','',
 '- 工作点：12、15、18 m/s，深度 20 m，初始实际执行器、命令历史与预测计划均填充直航配平。无海流、噪声、RL、残差前馈或进度反馈。预测器 N=35、采样 0.1 s；真实艇体 RK4 子步 0.02 s。',
 '- 定义 q=[east_ref/8, (depth_ref-20)/5, (VN_ref-V0)/2]，e=[east_ref-east, depth_ref-depth, VN_ref-VN]/[8,5,2]；8 m、5 m、2 m/s 是同一工程误差阈值尺度。H:q→e。归一化、三个输入的选择及参考 preview 均构成传递矩阵定义的一部分。',
 '- 单次仅激励一个独立输入，三个独立仿真组成完整 3×3 矩阵。其余参考由解析几何约束生成：east/depth 的导数给对应速度，北位置是 VN 的积分，yaw/pitch 来自速度切线。MPC 始终收到 t+0.1…t+3.5 s 的同一个解析参考。',
 '- 每线归一化幅值 0.006（物理幅值分别 0.048 m、0.030 m、0.012 m/s），七线多正弦采用 Schroeder 相位；16 s 初始段后用两个独立 64 s 整周期窗口。所选 bin 均为偶数，实际共同基周期为32 s，64 s窗口仍完整覆盖整数周期。',
 '- 频率为 2π/64×[2,4,6,8,12,16,24] rad/s。每配置执行零激励轨迹，逐时刻扣除基线并去直流；以 2/N Σe(t)exp(-jωt) 与输入相应系数之比估计复数 H。稳态分量满足 e(t)=Re{Hq̂ exp(jωt)}。最终H用第二个64 s窗口；保留第一个窗口验证周期收敛。',
 '- fin_0p9 是双舵相对标称舵效×0.9；delay5 是全部执行器从3个延迟子步变为5个，即0.06→0.10 s；tau2 是全部执行器时间常数×2；fin_tau2 是额外分离双舵时间常数×2；second_order 为全部执行器改成仓库离散临界阻尼二阶；combined=.9双舵效+全部执行器二阶。其余艇体参数固定为预测器使用的 MISMATCHED_PLANT。',
 '- 15 m/s 六个主要配置另做半幅0.003复验。12/18 m/s执行matched、second_order、combined各三轴及零激励，并对matched与combined做半幅复验。二阶所有通道包含推力执行器，应与仅双舵二阶的实验区分。','',
 '## 采样带最大奇异值与方向','',
 '| 航速 | 配置 | 频率 rad/s | σmax | 最大右向量幅值 [east,depth,VN] | 同一向量失配/匹配误差增益 |','|---:|---|---:|---:|---|---:|']
 for p in peaks:
  mags=', '.join(f'{x:.4f}' for x in p['direction_magnitudes'])
  lines.append(f"| {p['speed']:g} | {p['config']} | {p['peak_omega']:.4f} | {p['peak_sigma']:.5f} | [{mags}] | {p['same_direction_ratio_at_peak']:.3f} |")
 lines+=['','同方向比较固定每个失配矩阵的最大右向量 v，计算 ‖H_m v‖₂/‖H_matched v‖₂，避免分别比较两个矩阵最大奇异值时悄悄更换输入方向。这个比值仍可能受匹配误差很小的分母影响，不是稳定裕度。','',
 '15 m/s 下：fin_0p9最敏感方向主要为depth；second_order及全部时间常数加倍转为VN；combined再次由depth主导。12 m/s combined最大增益高于15 m/s，但这仍是小幅局部结果，不能直接预测大幅机动的越界时刻。18 m/s combined的三个奇异值为[0.0969085,0.0966464,0.0963337]，差异不足0.6%，此时全部三个方向几乎同样敏感；微小耦合或数值变化会显著旋转最大右奇异向量，不能宣称唯一最危险组合。', '',
 '## 复验明细','', '| 航速 | 配置 | 周期间 H 最大相对变化 | 半幅 H 最大相对变化 | 非激励输出 RMS 最大占比 |','|---:|---|---:|---:|---:|']
 for p in peaks:
  half='未测' if p['half_max'] is None else f"{100*p['half_max']:.3f}%"
  lines.append(f"| {p['speed']:g} | {p['config']} | {100*p['period_max']:.4f}% | {half} | {100*p['distortion_max']:.3f}% |")
 metas=[json.loads(p.read_text()) for p in OUT.glob('v*.json')]
 lines+=['',f"共完成 {len(metas)} 次非线性闭环仿真，每次144 s，保留全部0.1 s原始记录。总QP失败={sum(m['qp_failures'] for m in metas)}；全部记录最大推力比例={max(m['max_thrust_fraction'] for m in metas):.6f}；最大舵命令={max(max(m['max_abs_fin_deg']) for m in metas):.3f}°；命令饱和率最大值={max(max(m['saturation_fraction']) for m in metas):.6f}。",
 '','非激励输出RMS占比按扣基线与均值后、剔除所有七条激励谱线的残差计算，包含真实非线性混频、数值误差与未完全衰减瞬态；这不是测量噪声置信区间。主跟踪误差很小时，该比例可相对较大，不能直接等同于H主方向误差。半幅矩阵变化与周期变化应共同读。12/18 m/s的second_order未另做半幅，额外fin_tau2也未半幅复验；工作点扩展和半幅结果仍不构成对所有航速/振幅的认证。','',
 '参考几何一致性另由数值微分核查：三个航速/三轴上，位置参考的导数与速度参考最大差4.08e-8 m/s，姿态切线方向最大差2.23e-16；检查结果见frequency_reference_checks.json。','',
 '## 可复现文件','',
 '`frequency_identification.py` 运行与估计；`frequency_report.py` 生成本报告和四张PNG；`frequency_data/v*.npz` 保存完整原始参考、状态、输出、e/q、控制、执行器和QP标志；每个JSON保存配置与约束统计；`frf_*.npz` 保存两个周期的复数H、奇异值、单位复右向量；`frequency_summary.json`、`frequency_validation.json` 与 `frequency_peak_summary.csv` 可独立复核数值。','',
 '复现命令（仓库根目录的父目录，环境 `.venv-gs12`）：','```sh',
 '.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 15 --configs matched fin_0p9 delay5 tau2 fin_tau2 second_order combined --baseline',
 '.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 15 --configs matched fin_0p9 delay5 tau2 second_order combined --amplitude .003',
 '.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 12 18 --configs matched second_order combined --baseline',
 '.venv-gs12/bin/python gs12_followup/frequency_identification.py --speeds 12 18 --configs matched combined --amplitude .003',
 '.venv-gs12/bin/python gs12_followup/frequency_report.py','```','',
 '## IMC 与方向复验的边界','',
 '闭环 reference→error 数据本身不能唯一分解出 plant P 与 IMC controller Q，尤其本控制器含未来参考、滚动优化和可能变化的约束集合。因此H只可称为该参考生成器的局部误差传递矩阵（S-like），此处不反演Q、不构造未经额外plant激励验证的IMC等价模型，也不把sigma或同方向比值称为论文RSI。',
 '','用于后续方向实验必须保留复数相位：q(t)=a Re{v exp(jωt)}，其中v的全局相位可任取，三个相对相位不可丢弃。原始数据保留每个频率的完整v及幅相；单看柱状幅值图不足以重现复合方向。两种最敏感方向由根实验脚本做单频方向激励、预测器修改和独立约束/大幅检验。']
 (BASE/'frequency_notes.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps(peaks,indent=2))
if __name__=='__main__':main()
