"""Independent amplitude check after the frozen hybrid development experiment."""
import os
for _name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):
    os.environ[_name]="1"
from concurrent.futures import ProcessPoolExecutor,as_completed
import json
from pathlib import Path
import numpy as np
from hybrid_experiments import run_hybrid_case,CONFIGS,sha
from frequency_identification import reference,OMEGA,PHASE,SETTLE,PERIOD,SCALE

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"hybrid_results/half_amplitude"


def run_one(axis):
    meta,arrays=run_hybrid_case(CONFIGS["combined"],15.,lambda t:reference(t,15.,axis,.003),144.,False)
    assert len(arrays["time"])==7200 and np.isfinite(arrays["state"]).all()
    refs=arrays["reference"][4::5]
    arrays.update(time_s=arrays["time"][4::5],error_normalized=arrays["error"][4::5][:,[1,2,5]]/SCALE,
                  input_normalized=np.column_stack((refs[:,1],refs[:,2]-20.,refs[:,5]-15.))/SCALE)
    np.savez_compressed(OUT/f"axis{axis}.npz",**arrays)
    (OUT/f"axis{axis}.json").write_text(json.dumps(meta,indent=2)+"\n")
    return axis


def main():
    OUT.mkdir(exist_ok=False)
    baseline_path=ROOT/"hybrid_results/hybrid25_axis-1.npz"
    protocol=dict(purpose="Check amplitude consistency of SVD-informed hybrid25 candidate after initial 22-case development regression",
        no_controller_change=True,axes=[0,1,2],amplitude_per_line_normalized=.003,speed_mps=15.,plant="combined",
        duration_s=144.,omega_radps=OMEGA.tolist(),phases_rad=PHASE.tolist(),scale=SCALE.tolist(),
        existing_zero_excitation_baseline_sha256=sha(baseline_path),
        source_sha256={p.name:sha(p) for p in (Path(__file__),ROOT/"hybrid_experiments.py",ROOT/"hybrid_controller.py",ROOT/"improvement_experiments.py",ROOT/"improved_controller.py",ROOT/"plant_harness.py",ROOT/"frequency_identification.py")})
    (OUT/"protocol.json").write_text(json.dumps(protocol,indent=2)+"\n")
    with ProcessPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(run_one,axis) for axis in range(3)]):print(json.dumps({"completed_axis":future.result()}),flush=True)
    baseline=np.load(baseline_path)["error_normalized"]
    h=np.empty((2,len(OMEGA),3,3),complex);distortion=[]
    for axis in range(3):
        d=np.load(OUT/f"axis{axis}.npz");t=d["time_s"];e=d["error_normalized"]-baseline;u=d["input_normalized"][:,axis]
        for period in range(2):
            mask=(t>SETTLE+period*PERIOD+1e-8)&(t<=SETTLE+(period+1)*PERIOD+1e-8)
            tt,ee,uu=t[mask],e[mask],u[mask]
            ph=np.exp(-1j*tt[:,None]*OMEGA);E=2/len(tt)*ph.T@ee;U=2/len(tt)*ph.T@uu
            np.testing.assert_allclose(np.abs(U),.003,atol=1e-12,rtol=1e-9)
            h[period,:,:,axis]=E/U[:,None]
            if period==1:
                residual=ee-ee.mean(0)-np.real(np.exp(1j*tt[:,None]*OMEGA)@E)
                distortion.append(float(np.linalg.norm(residual)/np.linalg.norm(ee-ee.mean(0))))
    H=h[1];full=np.load(ROOT/"hybrid_results/frf_hybrid25.npz")
    _,singular,vh=np.linalg.svd(H);v=vh.conj().transpose(0,2,1)[:,:,0]
    relative=np.linalg.norm(H-full["H"],axis=(1,2))/np.linalg.norm(full["H"],axis=(1,2))
    overlap=np.abs(np.einsum("fi,fi->f",v.conj(),full["right_max_vector"]))
    period_change=np.linalg.norm(h[1]-h[0],axis=(1,2))/np.linalg.norm(H,axis=(1,2))
    result=dict(amplitude_relative_matrix_difference=relative.tolist(),max_relative_matrix_difference=float(relative.max()),
        top_direction_overlap=overlap.tolist(),min_top_direction_overlap=float(overlap.min()),
        period_relative_change=period_change.tolist(),unexcited_output_rms_fraction_by_input=distortion,
        singular_values=singular.tolist(),peak_sigma=float(singular[:,0].max()),omega_radps=OMEGA.tolist(),
        interpretation="Finite amplitude consistency check at seven sampled frequencies, not unseen plant validation or robust-stability certification")
    np.savez_compressed(OUT/"frf_hybrid25_a0.003.npz",H=H,H_period1=h[0],omega_radps=OMEGA,singular_values=singular,right_max_vector=v)
    (OUT/"validation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)


if __name__=="__main__":main()
