"""Reproduce hybrid candidate comparison figures and development notes."""
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"hybrid_results"


def main():
    frequency=json.loads((OUT/"frequency_summary.json").read_text())
    stress=json.loads((OUT/"summary.json").read_text())
    half=json.loads((OUT/"half_amplitude/validation.json").read_text())
    frequency.setdefault("validation_limit_at_initial_full_amplitude_analysis",frequency["validation_limit"])
    frequency["validation_limit"]="Half-amplitude consistency validation is stored separately in half_amplitude/validation.json; development regression on previously studied plants and seven frequencies, no unseen-plant or unsampled-frequency claim"
    frequency["supplementary_half_amplitude_validation"]={
        "file":"half_amplitude/validation.json",
        "sha256":hashlib.sha256((OUT/"half_amplitude/validation.json").read_bytes()).hexdigest(),
        "maximum_relative_matrix_difference":half["max_relative_matrix_difference"]}
    (OUT/"frequency_summary.json").write_text(json.dumps(frequency,indent=2)+"\n")
    sources={"baseline22":ROOT/"frequency_data/frf_v15_combined_a0.006.npz",
             "conservative22":ROOT/"improvement_frequency_results/frf_conservative22.npz",
             "order25":ROOT/"improvement_frequency_results/frf_order25.npz",
             "hybrid25":OUT/"frf_hybrid25.npz"}
    data={name:np.load(path) for name,path in sources.items()}
    omega=data["baseline22"]["omega_radps"]
    _,base_s,vh=np.linalg.svd(data["baseline22"]["H"])
    vmin=vh.conj().transpose(0,2,1)[:,:,-1]
    vmax=vh.conj().transpose(0,2,1)[:,:,0]
    directions=dict(omega_radps=omega.tolist(),baseline_min_direction_abs=np.abs(vmin).tolist(),
                    baseline_max_direction_abs=np.abs(vmax).tolist(),method={})
    for name,d in data.items():
        H=d["H"]
        directions["method"][name]=dict(pure_VN_axis_gain=np.linalg.norm(H[:,:,2],axis=1).tolist(),
            on_baseline_min_SVD_direction=np.linalg.norm(np.einsum("fij,fj->fi",H,vmin),axis=1).tolist(),
            on_baseline_max_SVD_direction=np.linalg.norm(np.einsum("fij,fj->fi",H,vmax),axis=1).tolist())
    (OUT/"svd_direction_comparison.json").write_text(json.dumps(directions,indent=2)+"\n")
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout="constrained")
    for name,d in data.items():
        H=d["H"];s=np.linalg.svd(H,compute_uv=False)
        axes[0,0].semilogy(omega,s[:,0],"o-",label=name)
        axes[0,1].semilogy(omega,np.linalg.norm(H[:,:,2],axis=1),"o-",label=name)
        axes[1,0].semilogy(omega,np.linalg.norm(H[:,:,1],axis=1),"o-",label=name)
    axes[0,0].set_title("Largest singular value at seven measured frequencies")
    axes[0,1].set_title("Pure normalized VN reference axis: ||H e_VN||")
    axes[1,0].set_title("Pure normalized depth reference axis: ||H e_depth||")
    for ax in (axes[0,0],axes[0,1],axes[1,0]):
        ax.set_xlabel("Frequency [rad/s]");ax.set_ylabel("Normalized error gain");ax.grid(alpha=.3)
    axes[0,0].legend(fontsize=8)
    ratios=[item["comparison_conservative22"]["position_RMSE_ratio"] for item in stress]
    axes[1,1].plot(np.arange(1,19),ratios,"o-")
    axes[1,1].axhline(1,color="k",ls="--",lw=.8)
    axes[1,1].set_xticks(np.arange(1,19))
    axes[1,1].set_title("24 s position RMS: hybrid25 / conservative22")
    axes[1,1].set_xlabel("Stress case index (table in notes)")
    axes[1,1].set_ylabel("RMS ratio");axes[1,1].grid(alpha=.3)
    fig.savefig(ROOT/"hybrid_findings.png",dpi=170)
    fig.savefig(ROOT/"hybrid_findings.pdf")
    plt.close(fig)
    pure_base=directions["method"]["baseline22"]["pure_VN_axis_gain"][-1]
    pure_hybrid=directions["method"]["hybrid25"]["pure_VN_axis_gain"][-1]
    min_base=directions["method"]["baseline22"]["on_baseline_min_SVD_direction"][-1]
    min_hybrid=directions["method"]["hybrid25"]["on_baseline_min_SVD_direction"][-1]
    lines=["# SVD发现驱动的混合预测器开发候选", "",
        "hybrid25 保留原MPC目标、权重、约束和优化器，只将推力通道预测改为名义二阶，双舵保持保守一阶（舵效0.85、时间常数×2）。额外3个状态中仅推力速率起作用，双舵速率恒为0。推力速率观测器只使用前后两次测得的执行器位置、已发出的指令和3槽历史，不读取真实植物隐藏速率、时间常数或增益。", "",
        "该候选是在原始SVD/方向试验已经显示“全通道二阶改善速度而恶化深度，保守一阶缓解深度而保留速度误差”后提出的。因此这是明确的开发回归，不是未见留出测试。先冻结 hybrid_results/protocol.json 与源码哈希，再做独立验证和18条压力、4条144 s频域记录；其后保持控制器不变，另冻结 half_amplitude/protocol.json 并补3条半幅频域记录。", "",
        "## 独立实现验证", "",
        "混合结构逐步传播与独立Torch RK4比较最大差1.11e-16，因果推力速率重建最大差5.55e-16，雅可比与有限差分最大差3.05e-10。纯推力情形完整传播与order25一致；恒定推力下双舵传播与conservative22最大差2.08e-17。无效双舵速率对预测的雅可比严格为0，原仓库维度仍为22。验证详细结果见 validation.json。", "",
        "## 18条相同工况压力回归", "",
        "沿用此前54例的12/15/18 m/s、纯深度/耦合、matched/combined/combined_tau_shift，完全相同时间参考、植物、初始基线配平和每0.02 s首越界停止规则。hybrid与保守一阶均18/18完成24 s，所有QP成功。共同24 s位置向量RMSE比值为 "
        f"{min(ratios):.6f}–{max(ratios):.6f}，14例略差、4例略好，说明压力跟踪表现基本持平，不能宣称全面改善。这些大幅压力机动仍有命令和实际执行器饱和；后文局部频域记录无饱和的结论不能外推到压力矩阵。", "",
        "|编号|航速 m/s|机动|植物|hybrid/保守位置RMSE|", "|---:|---:|---|---|---:|"]
    for i,item in enumerate(stress,1):
        lines.append(f"|{i}|{item['speed_mps']:g}|{item['maneuver']}|{item['plant_name']}|{item['comparison_conservative22']['position_RMSE_ratio']:.6f}|")
    lines += ["", "## 频域收益与回归", "",
        "15 m/s、combined植物，输入为独立 east/depth/VN 参考参数，输出为对应跟踪误差；输入输出均以[8 m,5 m,2 m/s]归一化。每轴7条归一化幅值0.006的正弦叠加，16 s过渡、两个64 s周期，取80–144 s识别；用同控制器的零激励轨迹去除稳态漂移。所有4条主记录均无QP失败、命令/实际执行器饱和或诊断越界。", "",
        "|频率 rad/s|baseline最大σ|conservative最大σ|order25最大σ|hybrid最大σ|hybrid/baseline|", "|---:|---:|---:|---:|---:|---:|"]
    singular={name:np.linalg.svd(d["H"],compute_uv=False)[:,0] for name,d in data.items()}
    for k,w in enumerate(omega):
        lines.append(f"|{w:.6f}|{singular['baseline22'][k]:.8f}|{singular['conservative22'][k]:.8f}|{singular['order25'][k]:.8f}|{singular['hybrid25'][k]:.8f}|{singular['hybrid25'][k]/singular['baseline22'][k]:.5f}|")
    lines += ["",
        "hybrid在七个已测频点的最大σ为0.10446295，出现在2.35619 rad/s，低于baseline的0.12198841，约降低14.37%；与强保守一阶的0.10449349几乎相同。其最大方向仍近于纯深度。前六个频点的最大σ却是baseline的1.86–3.12倍，保留了保守策略的低中频代价；没有实现全频改善，也不能排除未测频点的新峰。", "",
        f"纯归一化速度参考单位向量 e_VN 的增益定义为 ||H e_VN||₂。在最高频率，它从 {pure_base:.10f} 降至 {pure_hybrid:.10f}，降低 {100*(1-pure_hybrid/pure_base):.4f}%，与order25相同。这是纯VN输入轴的收益，不是原最小SVD方向的收益。", "",
        f"另用同一baseline FRF的原最小右奇异向量进行严格同方向比较：最高频率其幅值分量|v|={np.abs(vmin[-1]).round(8).tolist()}（east/depth/VN），baseline增益 {min_base:.10f}，hybrid增益 {min_hybrid:.10f}，降低 {100*(1-min_hybrid/min_base):.4f}%。该数来自多正弦矩阵重构，不应与此前单频方向激励试验混表。完整七点和旧最大方向比较见 svd_direction_comparison.json。", "",
        "主幅值下两个周期的FRF矩阵最大相对变化为 "
        f"{max(frequency['period_relative_change']):.3g}；三轴非激励频率残差/中心化误差RMS分别为 "
        +"、".join(f"{100*v:.3f}%" for v in frequency["unexcited_output_rms_fraction_by_input"])+"。这小于保守一阶横向输入此前约20%的残差，但仍需幅值一致性检查。", "",
        "## 半幅一致性检查", "",
        "主幅值frequency_summary.json最初生成早于半幅检查，其当时的限制文字保存在validation_limit_at_initial_full_amplitude_analysis；本报告生成器在最终复现步骤补入supplementary_half_amplitude_validation文件及哈希。原模拟脚本和执行前冻结的源码未更改。另对三轴采用0.003每谱线幅值，复用同一零激励记录，并保持模型、优化器、参考频率和时窗不变。七点FRF与0.006幅值结果的最大相对矩阵差为 "
        f"{100*half['max_relative_matrix_difference']:.4f}%，最坏方向复内积绝对值最小为 {half['min_top_direction_overlap']:.9f}；半幅最大σ为 {half['peak_sigma']:.8f}。半幅三轴非激励频率残差分别为 "
        +"、".join(f"{100*v:.3f}%" for v in half["unexcited_output_rms_fraction_by_input"])+"。这支持该幅值范围和七个频点上的局部响应解释，不替代对参数区间、噪声、其他工况或全频段稳定性的验证。", "",
        "## 文件与复现", "",
        "hybrid_controller.py定义预测器/因果观测器与独立验证；hybrid_experiments.py在私有模块中复用未修改的原实验循环；hybrid_half_amplitude.py独立执行半幅检查；hybrid_report.py生成本报告及图。运行结果、冻结协议、25条原始NPZ、同前缀比较和7点FRF均在hybrid_results/。", "",
        "复现顺序：使用相同依赖运行 `.venv-gs12/bin/python gs12_followup/hybrid_experiments.py`、`hybrid_half_amplitude.py`、`hybrid_report.py`。前两脚本要求新输出目录；比较所用原始baseline/conservative/order25数据需先由对应脚本产生。", ""]
    (ROOT/"hybrid_notes.md").write_text("\n".join(lines))
    print(json.dumps(dict(raw_cases=25,stress_cases=18,full_amplitude_frf_cases=4,half_amplitude_frf_cases=3,
                         peak_sigma=frequency["peak_sigma"],amplitude_difference=half["max_relative_matrix_difference"])))


if __name__=="__main__":main()
